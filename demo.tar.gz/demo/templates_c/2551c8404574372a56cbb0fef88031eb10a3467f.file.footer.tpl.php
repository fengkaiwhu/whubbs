<?php /* Smarty version Smarty-3.1.21-dev, created on 2014-12-22 13:56:16
         compiled from "./templates/footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:33981954854940821b21118-51812570%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2551c8404574372a56cbb0fef88031eb10a3467f' => 
    array (
      0 => './templates/footer.tpl',
      1 => 1419227690,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '33981954854940821b21118-51812570',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_54940821b21ab8_32754529',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_54940821b21ab8_32754529')) {function content_54940821b21ab8_32754529($_smarty_tpl) {?>





  <?php echo '<script'; ?>
>
            foucs_module.run();
  <?php echo '</script'; ?>
>

        <!-- 全局脚本 -->
 <?php echo '<script'; ?>
 src="js/global.js"><?php echo '</script'; ?>
>

</BODY>


</HTML>
<?php }} ?>
