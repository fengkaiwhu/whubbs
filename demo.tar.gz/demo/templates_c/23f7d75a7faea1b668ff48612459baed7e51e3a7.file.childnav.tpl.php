<?php /* Smarty version Smarty-3.1.21-dev, created on 2014-12-22 13:56:44
         compiled from "./templates/childnav.tpl" */ ?>
<?php /*%%SmartyHeaderCode:15370861925497aacaf0acd1-91536615%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '23f7d75a7faea1b668ff48612459baed7e51e3a7' => 
    array (
      0 => './templates/childnav.tpl',
      1 => 1419227773,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '15370861925497aacaf0acd1-91536615',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5497aacaf0c954_58422102',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5497aacaf0c954_58422102')) {function content_5497aacaf0c954_58422102($_smarty_tpl) {?><nav class="navbar navbar-default userdefine" role="navigation">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
     
      <a class="navbar-brand" href="#"> 
      	珞珈山水
      </a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li>
        	<a href="./usermanagemenu.php">控制面板首页</a>
        </li>
        <li>
        	<a href="./modifyuserdata.php">基本资料修改</a>
        </li>
       	<li>
        	<a href="./changepasswd.php">昵称密码修改</a>
        </li>

        <li>
        	<a href="./userparam.php">用户自定义参数</a>
        </li>
        <li>
        	<a href="./usermailbox.php">用户信件服务</a>
        </li>
       	<li>
        	<a href="./friendlist.php">编辑好友列表</a>
        </li>
     	
     	<li>
        	<a href="./modifyfavboards.php">收藏版面管理</a>
        </li>
      </ul>
     
	    </div><!-- /.navbar-collapse -->
	  </div><!-- /.container-fluid -->
	</nav><?php }} ?>
