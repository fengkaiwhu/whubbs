<?php /* Smarty version Smarty-3.1.18, created on 2014-12-21 08:44:48
         compiled from ".\templates\indexshow.tpl" */ ?>
<?php /*%%SmartyHeaderCode:4505548850c5b2f368-72065127%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '262bc2f138d93a287bd4eb14f9a55b85db2f0b06' => 
    array (
      0 => '.\\templates\\indexshow.tpl',
      1 => 1419147882,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '4505548850c5b2f368-72065127',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_548850c5b81403_68146080',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_548850c5b81403_68146080')) {function content_548850c5b81403_68146080($_smarty_tpl) {?>
<div class="mcontainer">
    <!-- container begin-->
				
	<div class="wrapper index-content-wrapper">
    	<div class="bottom">
    		<div class="inner-wrapper">
    			<div class="stories">
    				<div class="reps clearfix">

   						<a target="_blank" href="/testsmarty/secondary.php" class="rep current" id="foucs_tab_1" data-type="topic" data-token="" title="十大热帖">
						    <span class="info-card">十大热帖</span>
						    <img src="img/one.jpg" >
						</a>

					    <a target="_blank" href="/testsmarty/secondary.php" class="rep" id="foucs_tab_2" data-type="topic" data-token="" title="推荐版面" >
					    	<span class="info-card">推荐版面</span>
					 		<img src="img/two.jpg" >
					    </a>

					    <a target="_blank" href="/testsmarty/secondary.php" class="rep" id="foucs_tab_3" data-type="topic" data-token="" title="体育健身">
					    	<span class="info-card">体育健身</span>
					        <img src="img/three.jpg" >
					    </a>

					    <a target="_blank" href="/testsmarty/secondary.php" class="rep" id="foucs_tab_4" data-type="topic" data-token="" title="文学艺术">
					    	<span class="info-card">文学艺术</span>
					    	<img src="img/four.jpg" >
					    </a>

					    <a target="_blank" href="/testsmarty/secondary.php" class="rep" id="foucs_tab_5" data-type="topic" data-token="" title="本站系统">
					    	<span class="info-card">本站系统</span>
					    	<img src="img/five.jpg" >
					    </a>

					    <a target="_blank" href="/childClass" class="rep" id="foucs_tab_6" data-type="topic" data-token="" title="武汉大学">
					    	<span class="info-card">武汉大学</span>
					    	<img src="img/six.jpg" >
					    </a>

					    <a target="_blank" href="/childClass" class="rep" id="foucs_tab_7" data-type="topic" data-token="" title="电脑网络">
					    	<span class="info-card">电脑网络</span>
							<img src="img/seven.jpg" >
					    </a>

					    <a target="_blank" href="/childClass" class="rep" id="foucs_tab_8" data-type="topic" data-token="" title="社会信息">
					    	<span class="info-card">社会信息</span>
							<img src="img/eight.jpg" >
					    </a>

					    <a target="_blank" href="/childClass" class="rep" id="foucs_tab_9" data-type="topic" data-token="" title="科学技术">
					    	<span class="info-card">科学技术</span>
					  		<img src="img/night.jpg" >
					    </a>


					     <a target="_blank" href="/childClass" class="rep" id="foucs_tab_7" data-type="topic" data-token="" title="电脑网络">
					    	<span class="info-card">乡校情谊</span>
							<img src="img/seven.jpg" >
					    </a>

					    <a target="_blank" href="/childClass" class="rep" id="foucs_tab_8" data-type="topic" data-token="" title="社会信息">
					    	<span class="info-card">帮助</span>
							<img src="img/eight.jpg" >
					    </a>

					    <a target="_blank" href="/childClass" class="rep" id="foucs_tab_9" data-type="topic" data-token="" title="科学技术">
					    	<span class="info-card">科学技术</span>
					  		<img src="img/night.jpg" >
					    </a>

					   
    				</div>

					<!--右栏重复出现9次，-->
    				<div class="single-story" id="foucs_con_1">
		 	 			<div class="single-story-inner">
		    				<img class="author-img" src="img/one.jpg">
		    				<div class="story-title">
		    					<div>
		    						<a class="name" href="" target="_blank">十大热帖</a>
		    					</div>
							    <div>在山水上回答了 557 个问题，25854 人关注她。</div>
							</div>
						    <div class="sep"></div>
							<div class="story-content">
							    <div class="story-content-answer">
								    <span class="vote">
								    	5466
								    </span>
								     <p><a class="question_link" target="_blank" href="/testsmarty/disparticle.php">「保险」到底保险吗？</a></p>
							    </div>
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p><a class="question_link" target="_blank" href="/testsmarty/disparticle.php">「保险」到底保险吗？</a></p>
							    </div>
						    </div>
						    <div class="sep"></div>
						    <div class="story-end">
						    	sky 在 
						    	<a href="" target="_blank">中国</a>、
						    	<a href="" target="_blank">历史</a>、
						    	<a href="" target="_blank">生活</a> 等话题下获得了 13642 个赞同
						    </div>
						</div>
		    		</div>

		    		<div class="single-story undisplay" id="foucs_con_2">
		 	 			<div class="single-story-inner">
		    				<img class="author-img" src="img/two.jpg">
		    				<div class="story-title">
		    					<div>
		    						<a class="name" href="" target="_blank">推荐版面</a>
		    					</div>
							    <div>在山水上回答了 557 个问题，25854 人关注她。</div>
							</div>
						    <div class="sep"></div>
							<div class="story-content">
							    <div class="story-content-answer">
								    <span class="vote">
								    	5466
								    </span>
								     <p><a class="question_link" target="_blank" href="/testsmarty/topicView.php">「保险」到底保险吗？</a></p>
							    </div>
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p><a class="question_link" target="_blank" href="">凤凰传奇组合中的那个男人有什么用？</a></p>
							    </div>
						    </div>
						    <div class="sep"></div>
						    <div class="story-end">
						    	sky 在 
						    	<a href="" target="_blank">中国</a>、
						    	<a href="" target="_blank">历史</a>、
						    	<a href="" target="_blank">生活</a> 等话题下获得了 13642 个赞同
						    </div>
						</div>
		    		</div>

		    		<div class="single-story undisplay" id="foucs_con_3">
		 	 			<div class="single-story-inner">
		    				<img class="author-img" src="img/three.jpg">
		    				<div class="story-title">
		    					<div>
		    						<a class="name" href="" target="_blank">体育健身
		    					</div>
							    <div>在山水上回答了 557 个问题，25854 人关注她。</div>
							</div>
						    <div class="sep"></div>
							<div class="story-content">
							    <div class="story-content-answer">
								    <span class="vote">
								    	5466
								    </span>
								     <p><a class="question_link" target="_blank" href="/testsmarty/topicView.php">「保险」到底保险吗？</a></p>
							    </div>
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p><a class="question_link" target="_blank" href="">凤凰传奇组合中的那个男人有什么用？</a></p>
							    </div>
						    </div>
						    <div class="sep"></div>
						    <div class="story-end">
						    	sky 在 
						    	<a href="" target="_blank">中国</a>、
						    	<a href="" target="_blank">历史</a>、
						    	<a href="" target="_blank">生活</a> 等话题下获得了 13642 个赞同
						    </div>
						</div>
		    		</div>

		    		<div class="single-story undisplay" id="foucs_con_4">
		 	 			<div class="single-story-inner">
		    				<img class="author-img" src="img/four.jpg">
		    				<div class="story-title">
		    					<div>
		    						<a class="name" href="" target="_blank">文学艺术
		    					</div>
							    <div>在山水上回答了 557 个问题，25854 人关注她。</div>
							</div>
						    <div class="sep"></div>
							<div class="story-content">
							    <div class="story-content-answer">
								    <span class="vote">
								    	5466
								    </span>
							 	<p><a class="question_link" target="_blank" href="/testsmarty/topicView.php">「保险」到底保险吗？</a></p>
							    </div>
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p><a class="question_link" target="_blank" href="">凤凰传奇组合中的那个男人有什么用？</a></p>
							    </div>
						    </div>
						    <div class="sep"></div>
						    <div class="story-end">
						    	sky 在 
						    	<a href="" target="_blank">中国</a>、
						    	<a href="" target="_blank">历史</a>、
						    	<a href="" target="_blank">生活</a> 等话题下获得了 13642 个赞同
						    </div>
						</div>
		    		</div>

		    		<div class="single-story undisplay" id="foucs_con_5">
		 	 			<div class="single-story-inner">
		    				<img class="author-img" src="img/five.jpg">
		    				<div class="story-title">
		    					<div>
		    						<a class="name" href="" target="_blank">本站系统
		    					</div>
							    <div>在山水上回答了 557 个问题，25854 人关注她。</div>
							</div>
						    <div class="sep"></div>
							<div class="story-content">
							    <div class="story-content-answer">
								    <span class="vote">
								    	5466
								    </span>
								     <p><a class="question_link" target="_blank" href="/testsmarty/topicView.php">「保险」到底保险吗？</a></p>
							    </div>
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p><a class="question_link" target="_blank" href="">凤凰传奇组合中的那个男人有什么用？</a></p>
							    </div>
						    </div>
						    <div class="sep"></div>
						    <div class="story-end">
						    	sky 在 
						    	<a href="" target="_blank">中国</a>、
						    	<a href="" target="_blank">历史</a>、
						    	<a href="" target="_blank">生活</a> 等话题下获得了 13642 个赞同
						    </div>
						</div>
		    		</div>

		    		<div class="single-story undisplay" id="foucs_con_6">
		 	 			<div class="single-story-inner">
		    				<img class="author-img" src="img/six.jpg">
		    				<div class="story-title">
		    					<div>
		    						<a class="name" href="" target="_blank">武汉大学
		    					</div>
							    <div>在山水上回答了 557 个问题，25854 人关注她。</div>
							</div>
						    <div class="sep"></div>
							<div class="story-content">
							    <div class="story-content-answer">
								    <span class="vote">
								    	5466
								    </span>
								    <p><a class="question_link" target="_blank" href="/testsmarty/topicView.php">「保险」到底保险吗？</a></p>
							    </div>
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p><a class="question_link" target="_blank" href="">凤凰传奇组合中的那个男人有什么用？</a></p>
							    </div>
						    </div>
						    <div class="sep"></div>
						    <div class="story-end">
						    	sky 在 
						    	<a href="" target="_blank">中国</a>、
						    	<a href="" target="_blank">历史</a>、
						    	<a href="" target="_blank">生活</a> 等话题下获得了 13642 个赞同
						    </div>
						</div>
		    		</div>

		    		<div class="single-story undisplay" id="foucs_con_7">
		 	 			<div class="single-story-inner">
		    				<img class="author-img" src="img/seven.jpg">
		    				<div class="story-title">
		    					<div>
		    						<a class="name" href="" target="_blank">电脑网络
		    					</div>
							    <div>在山水上回答了 557 个问题，25854 人关注她。</div>
							</div>
						    <div class="sep"></div>
							<div class="story-content">
							    <div class="story-content-answer">
								    <span class="vote">
								    	5466
								    </span>
								    <p><a class="question_link" target="_blank" href="/testsmarty/topicView.php">「保险」到底保险吗？</a></p>
							    </div>
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p><a class="question_link" target="_blank" href="">凤凰传奇组合中的那个男人有什么用？</a></p>
							    </div>
						    </div>
						    <div class="sep"></div>
						    <div class="story-end">
						    	sky 在 
						    	<a href="" target="_blank">中国</a>、
						    	<a href="" target="_blank">历史</a>、
						    	<a href="" target="_blank">生活</a> 等话题下获得了 13642 个赞同
						    </div>
						</div>
		    		</div>

		    		<div class="single-story undisplay" id="foucs_con_8">
		 	 			<div class="single-story-inner">
		    				<img class="author-img" src="img/eight.jpg">
		    				<div class="story-title">
		    					<div>
		    						<a class="name" href="" target="_blank">社会信息
		    					</div>
							    <div>在山水上回答了 557 个问题，25854 人关注她。</div>
							</div>
						    <div class="sep"></div>
							<div class="story-content">
							    <div class="story-content-answer">
								    <span class="vote">
								    	5466
								    </span>
								    <p><a class="question_link" target="_blank" href="">「保险」到底保险吗？</a></p>
							    </div>
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p><a class="question_link" target="_blank" href="">凤凰传奇组合中的那个男人有什么用？</a></p>
							    </div>
						    </div>
						    <div class="sep"></div>
						    <div class="story-end">
						    	sky 在 
						    	<a href="" target="_blank">中国</a>、
						    	<a href="" target="_blank">历史</a>、
						    	<a href="" target="_blank">生活</a> 等话题下获得了 13642 个赞同
						    </div>
						</div>
		    		</div>

		    		<div class="single-story undisplay" id="foucs_con_9">
		 	 			<div class="single-story-inner">
		    				<img class="author-img" src="img/night.jpg">
		    				<div class="story-title">
		    					<div>
		    						<a class="name" href="" target="_blank">科学技术
		    					</div>
							    <div>在山水上回答了 557 个问题，25854 人关注她。</div>
							</div>
						    <div class="sep"></div>
							<div class="story-content">
							    <div class="story-content-answer">
								    <span class="vote">
								    	5466
								    </span>
								    <p><a class="question_link" target="_blank" href="">「保险」到底保险吗？</a></p>
							    </div>
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p><a class="question_link" target="_blank" href="">凤凰传奇组合中的那个男人有什么用？</a></p>
							    </div>
						    </div>
						    <div class="sep"></div>
						    <div class="story-end">
						    	sky 在 
						    	<a href="" target="_blank">中国</a>、
						    	<a href="" target="_blank">历史</a>、
						    	<a href="" target="_blank">生活</a> 等话题下获得了 13642 个赞同
						    </div>
						</div>
		    		</div>


		    			<div class="single-story undisplay" id="foucs_con_10">
		 	 			<div class="single-story-inner">
		    				<img class="author-img" src="img/night.jpg">
		    				<div class="story-title">
		    					<div>
		    						<a class="name" href="" target="_blank">科学技术
		    					</div>
							    <div>在山水上回答了 557 个问题，25854 人关注她。</div>
							</div>
						    <div class="sep"></div>
							<div class="story-content">
							    <div class="story-content-answer">
								    <span class="vote">
								    	5466
								    </span>
								    <p><a class="question_link" target="_blank" href="">「保险」到底保险吗？</a></p>
							    </div>
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p><a class="question_link" target="_blank" href="">凤凰传奇组合中的那个男人有什么用？</a></p>
							    </div>
						    </div>
						    <div class="sep"></div>
						    <div class="story-end">
						    	sky 在 
						    	<a href="" target="_blank">中国</a>、
						    	<a href="" target="_blank">历史</a>、
						    	<a href="" target="_blank">生活</a> 等话题下获得了 13642 个赞同
						    </div>
						</div>
		    		</div>

				

					<div class="single-story undisplay" id="foucs_con_11">
		 	 			<div class="single-story-inner">
		    				<img class="author-img" src="img/night.jpg">
		    				<div class="story-title">
		    					<div>
		    						<a class="name" href="" target="_blank">科学技术
		    					</div>
							    <div>在山水上回答了 557 个问题，25854 人关注她。</div>
							</div>
						    <div class="sep"></div>
							<div class="story-content">
							    <div class="story-content-answer">
								    <span class="vote">
								    	5466
								    </span>
								    <p><a class="question_link" target="_blank" href="">「保险」到底保险吗？</a></p>
							    </div>
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p><a class="question_link" target="_blank" href="">凤凰传奇组合中的那个男人有什么用？</a></p>
							    </div>
						    </div>
						    <div class="sep"></div>
						    <div class="story-end">
						    	sky 在 
						    	<a href="" target="_blank">中国</a>、
						    	<a href="" target="_blank">历史</a>、
						    	<a href="" target="_blank">生活</a> 等话题下获得了 13642 个赞同
						    </div>
						</div>
		    		</div>


					<div class="single-story undisplay" id="foucs_con_12">
		 	 			<div class="single-story-inner">
		    				<img class="author-img" src="img/night.jpg">
		    				<div class="story-title">
		    					<div>
		    						<a class="name" href="" target="_blank">科学技术
		    					</div>
							    <div>在山水上回答了 557 个问题，25854 人关注她。</div>
							</div>
						    <div class="sep"></div>
							<div class="story-content">
							    <div class="story-content-answer">
								    <span class="vote">
								    	5466
								    </span>
								    <p><a class="question_link" target="_blank" href="">「保险」到底保险吗？</a></p>
							    </div>
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p><a class="question_link" target="_blank" href="">凤凰传奇组合中的那个男人有什么用？</a></p>
							    </div>
						    </div>
						    <div class="sep"></div>
						    <div class="story-end">
						    	sky 在 
						    	<a href="" target="_blank">中国</a>、
						    	<a href="" target="_blank">历史</a>、
						    	<a href="" target="_blank">生活</a> 等话题下获得了 13642 个赞同
						    </div>
						</div>
		    		</div>

		  		<!---->
				</div>
			</div>
		</div>

<!--Container and wrapper-->
	</div>
</div>
<?php }} ?>
