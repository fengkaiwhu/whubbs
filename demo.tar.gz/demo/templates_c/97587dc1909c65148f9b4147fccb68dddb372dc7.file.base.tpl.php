<?php /* Smarty version Smarty-3.1.21-dev, created on 2014-12-22 13:56:16
         compiled from "./templates/base.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1596813945549409aa0f3546-37134859%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '97587dc1909c65148f9b4147fccb68dddb372dc7' => 
    array (
      0 => './templates/base.tpl',
      1 => 1419227690,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1596813945549409aa0f3546-37134859',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_549409aa0f7fc6_85011954',
  'variables' => 
  array (
    'title' => 0,
    'Name' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_549409aa0f7fc6_85011954')) {function content_549409aa0f7fc6_85011954($_smarty_tpl) {?><HTML>
<HEAD>
<TITLE><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
 - <?php echo $_smarty_tpl->tpl_vars['Name']->value;?>
</TITLE>
<meta charset="utf-8">
<link rel="stylesheet" href="css/bootstrap.css">
<link rel="stylesheet" href="css/style.css" type="text/css" media="screen,print">
<link rel="stylesheet" href="css/fms.v2.css" >
 <?php echo '<script'; ?>
 src="js/jquery-1.11.1.min.js"><?php echo '</script'; ?>
>
 <?php echo '<script'; ?>
 src="js/bootstrap.min.js"><?php echo '</script'; ?>
>



<!–[if IE]>  
<?php echo '<script'; ?>
 src=”http://html5shiv.googlecode.com/svn/trunk/html5.js”><?php echo '</script'; ?>
>  
<![endif]–>  
   
</HEAD>
<BODY>

<?php }} ?>
