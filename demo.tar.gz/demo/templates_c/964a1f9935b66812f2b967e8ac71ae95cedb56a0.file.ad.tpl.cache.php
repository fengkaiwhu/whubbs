<?php /* Smarty version Smarty-3.1.18, created on 2014-12-21 11:25:01
         compiled from ".\templates\ad.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2092054968616adb1e2-70424352%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '964a1f9935b66812f2b967e8ac71ae95cedb56a0' => 
    array (
      0 => '.\\templates\\ad.tpl',
      1 => 1419157493,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2092054968616adb1e2-70424352',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_54968616adf068_13592950',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_54968616adf068_13592950')) {function content_54968616adf068_13592950($_smarty_tpl) {?><table cellspacing="0" cellpadding="0" align="center" class="navClass2 table">
    <tbody>
        <tr>
            <td width="100%">
                <table width="100%" align="center" border="0" cellspacing="0" cellpadding="0">
                    <tbody>
                        <tr>
                            <td class="TopDarkNav" height="9"></td>
                        </tr>
                        <tr>
                            <td height="70" class="TopLighNav2">

                                <table border="0" width="100%" align="center">
                                    <tbody>
                                        <tr>
                                            <td align="left" width="10%"><a href="/testsmarty/index.php">
                                                <img border="0" src="img/pic/ws.jpg"></a></td>
                                            <td align="center" width="80%">
                                                <script src="/bbsad.js"></script>
                                                <script>showContentAd();</script>
                                                <a href="http://bbs.whu.edu.cn/indexpages/now/" target="_blank">
                                                    <img border="0" src="img/ad/ad.jpg"></a>
                                            </td>
                                          
                                        </tr>
                                    </tbody>
                                </table>

                            </td>
                        </tr>
                        <tr>
                            <td class="TopLighNav" height="9"></td>
                        </tr>
              
                    </tbody>
                </table>
            </td>
        </tr>
    </tbody>
</table>
<?php }} ?>
