<?php /* Smarty version Smarty-3.1.21-dev, created on 2014-12-22 13:58:13
         compiled from "./templates/disparticle.tpl" */ ?>
<?php /*%%SmartyHeaderCode:534193795497b2f565d818-65900719%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'aa2aa7b995b296873896ffe2f454e0b981a0865f' => 
    array (
      0 => './templates/disparticle.tpl',
      1 => 1419227690,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '534193795497b2f565d818-65900719',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5497b2f569c0d3_26400349',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5497b2f569c0d3_26400349')) {function content_5497b2f569c0d3_26400349($_smarty_tpl) {?><?php  $_config = new Smarty_Internal_Config("test.conf", $_smarty_tpl->smarty, $_smarty_tpl);$_config->loadConfigVars("setup", 'local'); ?>
<?php echo $_smarty_tpl->getSubTemplate ("base.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('title'=>'foo'), 0);?>


<?php echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("left.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("right.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>


<div class="usermailcontainer">

<?php echo $_smarty_tpl->getSubTemplate ("ad.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>



    <table class="table disparticletop" width="97%">
        <tbody>
            <tr>
                <td width="2"></td>
                <td align="left" valign="middle" style="height: 27">
                    <table cellpadding="0" cellspacing="0" border="0">
                        <tbody>
                            <tr>
                                <td width="110"><a href="postarticle.php?board=WHU">
                                    <div class="buttonClass1" border="0" title="发新帖"></div>
                                </a></td>
                                <!--    <td width="110"><a href="#" onclick="alert('本功能尚在开发中！')"><div class="buttonClass2" border="0" title="发起新投票"></div></a></td>-->
                                <td width="110"><a href="postarticle.php?board=WHU&amp;reID=1105563173">
                                    <div class="buttonClass4" border="0" title="回复本主题"></div>
                                </a></td>
                            </tr>
                        </tbody>
                    </table>
                </td>
                <td align="right" valign="middle">
                    <a href="disparticle.php?boardName=WHU&amp;ID=1105563173&amp;pos=1&amp;mt=-1">
                        <img src="img/pic/prethread.gif" border="0" title="浏览上一篇主题" width="52" height="12"></a>&nbsp;
                <a href="javascript:this.location.reload()">
                    <img src="img/pic/refresh.gif" border="0" title="刷新本主题" width="40" height="12"></a> &nbsp;
                <a href="disparticle.php?boardName=WHU&amp;ID=1105563173&amp;start=0&amp;pos=1&amp;listType=1">
                    <img src="img/pic/treeview.gif" width="40" height="12" border="0" title="树形显示贴子"></a>
                    <a href="disparticle.php?boardName=WHU&amp;ID=1105563173&amp;pos=1&amp;mt=1">
                        <img src="img/pic/nextthread.gif" border="0" title="浏览下一篇主题" width="52" height="12"></a>

                </td>
            </tr>
        </tbody>
    </table>

    <!--
    <table class="disparticletop table">
        <tbody>
            <tr align="middle">
                <td align="left" valign="middle" width="100%" height="25">
                    <table width="100%" cellpadding="0" cellspacing="0" border="0">
                        <tbody>
                            <tr>
                                <th align="left" valign="middle" width="73%" height="25">&nbsp;* 文章主题： 著名谣言和非谣言列表（已更新）  
                                </th>
                                <th class="tiezifav">
                                    <a href="#" onclick="window.external.AddFavorite(location.href, document.title);">
                                        <img src="img/pic/fav_add1.gif" border="0" width="15" height="15" title="把本贴加入IE收藏夹"></a>&nbsp;
                                </th>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
        </tbody>
    </table>
    -->

    <table class="table tiezicontent">
        <tbody>
            <tr>
                <td valign="top" width="175">
                    <a name="a0"></a>
                    <table width="100%" cellpadding="2" cellspacing="0">
                        <tbody>
                            <tr>
                                <td width="*" valign="middle" style="filter: glow(color=#9898BA,strength=2)">&nbsp;
                                <nobr><a href="dispuser.php?id=DarkTemplar" target="_blank" title="查看DarkTemplar的个人资料" style="TEXT-DECORATION: none;"><font color="#990000"><b>DarkTemplar</b></font></a></nobr>
                                </td>
                                <td width="25" valign="middle">
                                    <img src="img/pic/ofmale.gif" border="0" title="帅哥哟，离线"></td>
                                <td width="10" valign="middle"></td>
                            </tr>
                        </tbody>
                    </table>


                    <!--************************************作者信息**********************-->
                    <div id="authorArea">

                        <div class="fm-header-bar" style="float: right; margin-top: 20px; margin-bottom: 20px;">
                            <div class="fm-main">
                                <div class="row-fluid">

                                    <dt class="w2 pr" style="overflow: visible">

                                        <a href="" class='fm_popovercard' data-obj_id='1' data-url='get_card.php?id='>

                                            <img src="img/userface/image55.gif" alt="kiki1010" class="authorAreaImg">
                                        </a>

                                    </dt>

                                </div>
                            </div>
                            <br />
                        </div>

                        <div class="spaceholder"></div>

                        <!--作者信息-->
                        <!--signature-->
                        <!--签名档-->
                        <div id="authorSignature" class="authorSignature">
                            <p>
                                有些事，明知是错的，也要去坚持，因为不甘心；有些人，明知是爱的，也要去放弃，因为没结
                                局；有时候，明知没路了，却还在前行，因为习惯了。
                            </p>
                        </div>
                        <!--signature-->
                    </div>

                    <!--************************************作者信息**********************-->







                    <td valign="top" width="*">

                       <?php echo $_smarty_tpl->getSubTemplate ("topicoperate.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

                        <table border="0" width="98%" style="table-layout: fixed; word-break: break-all">
                            <tbody>
                                <tr>

                                    <div id="topicTitle">
                                        <h2>著名谣言和非谣言列表（已更新）</h2>
                                    </div>
                                    <br />

                                    <td width="100%" style="font-size: 9pt; line-height: 12pt; padding: 0px 5px;">
                                    <b>发信人: DarkTemplar (树欲静而风不止，子欲养而亲不待), 信区: WHU</b>
                                <br>
                                       <b> 发信站: 珞珈山水BBS站 (Fri May 11 17:34:39 2007), 转信</b>
                                <br>
                                        &nbsp;<br>
                                        1、被证明是谣言：
                                <br>
                                        &nbsp; （1)历史类
                                <br>
                                        中国有个罗马村·谣言
                                <br>
                                        &nbsp; &nbsp; 新版历史教学大纲说岳飞文天祥不是民族英雄·谣言
                                <br>
                                        &nbsp; &nbsp; 北洋水师在定远舰的主炮上晾衣服·著名谣言
                                <br>
                                        &nbsp; &nbsp; 甲午赔款大部分被日本用于教育·谣言
                                <br>
                                        &nbsp; &nbsp; 毛泽东“感谢”日本侵略·谣言
                                <br>
                                        &nbsp; &nbsp; 联合国为周恩来逝世“破例”降半旗·著名谣言
                                <br>
                                        &nbsp; &nbsp; 斯大林下达纵火令·谣言
                                <br>
                                        苏联军队的入侵和中国进行核试·谣言
                                <br>
                                        苏修逼债导致中国饥荒·谣言
                                <br>
                                        &nbsp; &nbsp; “三年自然灾害”时期风调雨顺·谣言
                                <br>
                                        &nbsp; &nbsp; 1927-1937是民国经济的“黄金十年”·谣言
                                <br>
                                        &nbsp; &nbsp; 我军历史上的十大外战·谣言
                                <br>
                                        &nbsp; &nbsp; 林彪一个连打败一个师·谣言
                                <br>
                                        &nbsp; &nbsp; 解放战争初期苏联在东北交给中共大量武器·著名谣言
                                <br>
                                        &nbsp; &nbsp; 抗战期间八路军到处种鸦片·著名谣言
                                <br>
                                        &nbsp; &nbsp; 还白毛女传说的真实面目：黄世仁到底有多冤·谣言
                                <br>
                                        &nbsp; &nbsp; 孙立人是歼灭日军最多的中国将领和枪毙或活埋日本战俘·著名谣言
                                <br>
                                        &nbsp; &nbsp; 几百中国宪兵大战数万日军·谣言
                                <br>
                                        &nbsp; &nbsp; 79年越南人对PLA女兵的猎奇（海豹人）·谣言
                                <br>
                                        &nbsp; &nbsp; 德国皇帝和磨坊主关于拆迁的官司·谣言
                                <br>
                                        &nbsp; &nbsp; 某军阀的巨额“金娣存款”·谣言
                                <br>
                                        &nbsp;<br>
                                        &nbsp;<br>
                                        &nbsp; (2)盲目反外类
                                <br>
                                        美国中央情报局“中国十诫”·著名谣言
                                <br>
                                        CNN：曹刚川在美答问语出惊人·谣言
                                <br>
                                        &nbsp; &nbsp; 去麦当劳和肯德基吃饭一定要发票防止逃税·著名谣言
                                <br>
                                        一个在日本BBS上人气极旺的帖子·著名谣言
                                <br>
                                        长谷川弘一关于北洋水师战利品的谣言·著名谣言
                                <br>
                                        &nbsp; &nbsp; 在北大BBS引起轰动的帖子（我生长在东北的哈尔滨……）·谣言
                                <br>
                                        &nbsp; &nbsp; 新浪是日本背景,sina是“支那”·著名谣言
                                <br>
                                        BBC报道：日本暴徒街头公然强暴中国妇女·谣言
                                <br>
                                        鄂尔多斯，山羊以及日本的谣言·谣言
                                <br>
                                        &nbsp; &nbsp; 日本所有的煤气管道和水管都是用无缝钢管作的，一打仗就能改成炮管枪管
                                <br>
                                        &nbsp; &nbsp; 1994年何智丽跟邓亚萍比赛满口“哟西”·著名谣言（那两个字只是语气词，以前在国内比赛时就说）
                                <br>
                                        &nbsp; &nbsp; 日本小孩一句话，震惊每一个中国人
                                <br>
                                        &nbsp; &nbsp; 日本行为艺术家吃婴儿
                                <br>
                                        &nbsp; &nbsp; 罗刚事件和替罪羊·著名谣言（该条消息的真相已搞清：一个无赖冒充日本人发布辱华言论，并已受到法律惩罚）
                                <br>
                                        &nbsp; &nbsp; 松下高官挑衅：参拜不参拜无所谓，即使参拜，中国人也会买日货
                                <br>
                                        &nbsp; &nbsp; 浙大爱国教授讲演：大阪地震先救日本人后救中国人
                                <br>
                                        &nbsp; &nbsp; CECT手机为日本生产，问候语辱华
                                <br>
                                        &nbsp; &nbsp; 日本儿童画中国地图辱华
                                <br>
                                        &nbsp; &nbsp; 洛阳军方医院发现日本企业利用化妆品改变中国人基因
                                <br>
                                        &nbsp; &nbsp; 日本人访问中科院金属所盗取机密
                                <br>
                                        &nbsp; &nbsp; 日本人发明的宠物养殖技术：盆景猫
                                <br>
                                        &nbsp; &nbsp; BBC报道：中国俘虏日本潜艇
                                <br>
                                        &nbsp; &nbsp; 日军侵华期间改良了小龙虾的基因，并用其处理中国受害者尸体
                                <br>
                                        &nbsp; &nbsp; 多伦多街头日本人骂华人被当街扒掉衣服
                                <br>
                                        &nbsp; &nbsp; 日本各大媒体对中国居民被侵华日军遗弃的毒剂伤害的消息基本不作报道
                                <br>
                                        &nbsp; &nbsp; 真佩服李白，在唐朝就知道骂日本人了
                                <br>
                                        &nbsp; &nbsp; 日本人街头暴打陪酒女
                                <br>
                                        &nbsp; &nbsp; 赵薇因军旗装事件成为韩国人最讨厌的中国明星
                                <br>
                                        &nbsp; &nbsp; 丰田员工评价丰田汽车及日本人
                                <br>
                                        &nbsp; &nbsp; 朱总理答日本鬼子的话语
                                <br>
                                        &nbsp; &nbsp; 温总理在亚洲某次领导人峰会上接受记者采访时针对日本的强硬发言
                                <br>
                                        &nbsp; &nbsp; 刘德华在日本演唱会的强硬发言
                                <br>
                                        &nbsp; &nbsp; 刘翔以实际行动抵制日货
                                <br>
                                        &nbsp; &nbsp; 刘翔在某次比赛后对日本记者的强硬发言
                                <br>
                                        &nbsp; &nbsp; 风水先生：日本富豪将在中国上海建世界第一高楼并对中国不利
                                <br>
                                        &nbsp; &nbsp; 姚明拒绝日本丰田公司的巨额广告费代言邀请
                                <br>
                                        &nbsp; &nbsp; 北京外语大学的老教授在北京地铁暴打辱华的日本人并逼迫其下跪磕头道歉
                                <br>
                                        &nbsp; &nbsp; 日本媒体不报道奥斯威辛解放60周年纪念活动
                                <br>
                                        &nbsp; &nbsp; 无耻女大学生发帖媚日，一位先生的回帖极为精彩
                                <br>
                                        &nbsp; &nbsp; 中国煤填日本海
                                <br>
                                        &nbsp; &nbsp; 日本大量进口中国木材做成卫生筷子,又将其回收、造纸、卖给中国
                                <br>
                                        &nbsp; &nbsp; 中国将用过的安全套做成口香糖出口日本
                                <br>
                                        &nbsp; &nbsp; 长春某高校学生对来访的日本学生高唱“保卫钓鱼岛”，被该校领导强行拉下舞台
                                <br>
                                        &nbsp; &nbsp; 沈阳青年马臣买长刀、下战书，单枪匹马邀日本领事决斗，该领事因精神受刺激回国
                                <br>
                                        &nbsp; &nbsp; 日本人用英语骂“中国猪”，被中国哨兵一枪砸倒
                                <br>
                                        &nbsp; &nbsp; 北京某湖北三轮车夫将日本人推进臭水沟
                                <br>
                                        &nbsp; &nbsp; 在南京夫子庙，三岁的孩子朝日本老人脸上吐口水，几十名青年围攻日本游客
                                <br>
                                        &nbsp; &nbsp; 南京大学生在麦当劳痛扁小日本，店长溜走前嘱咐关好门，赶来的民警置之不理
                                <br>
                                        &nbsp; &nbsp; 某公司老总和日本一个财团在某酒家谈判，日方人员骂“支那猪”后被殴打
                                <br>
                                        &nbsp; &nbsp; 爱国青年强奸日本右翼家人
                                <br>
                                        &nbsp; &nbsp; 华奸马立诚在香港中环被爱国青年狂殴
                                <br>
                                        &nbsp; &nbsp; 韩国人爱国不买日货·谣言
                                <br>
                                        韩国人的一篇文章·谣言
                                <br>
                                        《胡志明青年报》 中国人永远是我们的敌人·谣言
                                <br>
                                        &nbsp;<br>
                                        &nbsp; (3)政治、军事类
                                <br>
                                        &nbsp; &nbsp; 俄罗斯：经济危机导致人口危机·谣言
                                <br>
                                        据说四年没有更新的中纪委网站·谣言
                                <br>
                                        来自金羊网的谣言·谣言
                                <br>
                                        厉以宁家族暴富内幕·谣言
                                <br>
                                        伪造的华莱士访谈·著名谣言 （采访确有其事，但不是网上流传的那个版本）
                                <br>
                                        &nbsp; &nbsp; 安徽志愿兵老兵东北乞讨·谣言
                                <br>
                                        &nbsp; &nbsp; 原39军少校老军人街头乞讨·迷惑性很大的谣言
                                <br>
                                        &nbsp; &nbsp; 台儿庄战役亲历者无一人获得抗战胜利60周年纪念章·谣言
                                <br>
                                        拯救女兵林奇·谣言
                                <br>
                                        &nbsp; &nbsp; 法卡山、老山划归越南·谣言
                                <br>
                                        &nbsp; &nbsp; 美国军人眼中的98抗洪·谣言
                                <br>
                                        &nbsp; &nbsp; google earth泄密·谣言
                                <br>
                                        台湾F16战机集体投诚事件·著名谣言
                                <br>
                                        中国菲律宾海上交火·谣言
                                <br>
                                        台湾没有8路车·谣言
                                <br>
                                        &nbsp; &nbsp; 以色列为什么对中国那么好（假托水均益之名）·谣言
                                <br>
                                        &nbsp; &nbsp; 何祚庥说矿难民工“谁叫你不幸生在中国了？”·谣言（无良记者掐头去尾的拼接）
                                <br>
                                        &nbsp;<br>
                                        &nbsp; (4)社会类
                                <br>
                                        “北大校花”参选国际小姐·谣言
                                <br>
                                        大三女生40万年薪·谣言
                                <br>
                                        哈佛最年轻的中国教授·谣言
                                <br>
                                        甲骨文总裁的演讲·著名谣言
                                <br>
                                        &nbsp; &nbsp; 中国少女打破牛津大学800年记录·谣言
                                <br>
                                        &nbsp; &nbsp; 欧美基本没人闯红灯·谣言
                                <br>
                                        &nbsp; &nbsp; 《吉祥三宝》抄袭法国《蝴蝶》·谣言
                                <br>
                                        &nbsp; &nbsp; 世界新七大奇迹网上评选·著名谣言（纯商业炒作）
                                <br>
                                        &nbsp;<br>
                                        &nbsp; (5)自然科学类
                                <br>
                                        &nbsp; &nbsp; “阿波罗登月”是伪造·谣言
                                <br>
                                        月球上可看见中国长城·著名谣言
                                <br>
                                        偷肾脏的谣言·著名谣言
                                <br>
                                        微波炉和输血·谣言
                                <br>
                                        美国的时间旅行者·谣言
                                <br>
                                        &nbsp; &nbsp; 百慕大魔鬼三角·这个谣言太著名了
                                <br>
                                        &nbsp; &nbsp; 德布罗意只有两页的博士论文获诺贝尔奖·著名谣言
                                <br>
                                        &nbsp;<br>
                                        &nbsp;<br>
                                        2. 被证实不是谣言
                                <br>
                                        马克思获BBC千年人物评选第一·属实
                                <br>
                                        美国: 考试作弊也是犯罪·属实
                                <br>
                                        世界名著百强鲁迅《狂人日记》入选·属实
                                <br>
                                        美国机载激光武器发展现状·属实
                                <br>
                                        林彪《571工程纪要》·属实
                                <br>
                                        哈佛女孩刘亦婷·属实
                                <br>
                                        巴西交换球衣内幕·属实
                                <br>
                                        “教授嫖娼死亡”的疑云·属实
                                <br>
                                        河南惊爆系列“食人”惨案·属实
                                <br>
                                        1994年建国门枪战·属实
                                <br>
                                        鉴定“哈佛博士”·属实
                                <br>
                                        &nbsp;<br>
                                        珞珈山水被公安部短期封站·属实
                                <br>
                                        上海地铁四号线事故·属实
                                <br>
                                        央视主持董关鹏博士造假·属实
                                <br>
                                        日本鬼子九一八珠海集体大嫖娼·属实
                                <br>
                                        张光斗:不要让农村的孩子上大学·属实
                                <br>
                                        大跃进中钱学森撰文证实亩产万斤·属实
                                <br>
                                        人民日报：宋美龄是“人民弃儿”·属实
                                <br>
                                        2003.11.中国潜艇出现日本海域·属实
                                <br>
                                        &nbsp;<br>
                                        3. 部分证实部分证伪
                                <br>
                                        &nbsp; &nbsp; 中国北伐军上海暴行求证·真伪各半
                                <br>
                                        西点军校学雷锋·真伪各半（西点学雷锋是因为服从命令）
                                <br>
                                        &nbsp; &nbsp; 北大校长哈佛被拒·真伪各半
                                <br>
                                        &nbsp; &nbsp; 《泰晤士报》随军记者日记·真伪各半
                                <br>
                                        &nbsp; &nbsp; 美一男子声称烧死布什而坐牢·真伪各半
                                <br>
                                        &nbsp; &nbsp; 日本干尸展览·真伪各半
                                <br>
                                        &nbsp; &nbsp; 中国航天院士海南被杀·真伪各半
                                <br>
                                        &nbsp; &nbsp; 西北大学抗日事件相关传言·真伪各半
                                <br>
                                        &nbsp; &nbsp; 陈兵朝鲜15万·真伪各半
                                <br>
                                        &nbsp; &nbsp; 布雷德利关于朝鲜战争“四个错误”的发言·真伪各半（说过这话，但是场合不对）
                                <br>
                                        &nbsp; &nbsp; 拿破仑的“睡狮”论·真伪各半（说过睡狮，但实际意义不同）
                                <br>
                                        &nbsp;<br>
                                        --
                                <br>
                                        &nbsp; &nbsp; 半个月亮珞珈那面爬上来，又是一年三月樱花开。这一别将是三年还五载，明年花开
                                <br>
                                        你还来不来。我真想这一辈子坐在樱花树下，弹着我的破吉他。雪白的花瓣贴着脸颊飘落
                                <br>
                                        下，美丽樱园我的家。梦中的樱花伴着珞珈的晚霞，你我曾在樱花树下渐渐长大。明天你
                                <br>
                                        将启航，去向海角天涯，别忘了她，咱们樱花树下的家。
                                <br>
                                        &nbsp;<br>
                                        &nbsp;<br>
                                        <font class="f006" color="blue">※ 修改:·DarkTemplar 于 Jul 11 11:44:03 修改本文·[FROM: 202.127.158.*]</font><font class="f000"> <br> </font><font class="f000"></font><font class="f009">※ 来源:·珞珈山水BBS站 bbs.whu.edu.cn·[FROM: 202.127.158.*]</font><font class="f000"> <br> </font></td>
                                </tr>
                            </tbody>
                        </table>
                    </td>

            </tr>
            <tr>
                <td class="TableBody2" valign="top" width="175">
                    <a name="a1"></a>
                    <table width="100%" cellpadding="2" cellspacing="0">
                        <tbody>
                            <tr>
                                <td width="*" valign="middle" style="filter: glow(color=#9898BA,strength=2)">&nbsp;
                                <nobr><a href="dispuser.php?id=ykxuewhu" target="_blank" title="查看ykxuewhu的个人资料" style="TEXT-DECORATION: none;"><font color="#990000"><b>ykxuewhu</b></font></a></nobr>
                                </td>
                                <td width="25" valign="middle">
                                    <img src="img/pic/ofmale.gif" border="0" title="帅哥哟，离线"></td>
                                <td width="10" valign="middle"></td>
                            </tr>
                        </tbody>
                    </table>

                    <!--************************************作者信息**********************-->
                    <div id="Div1">

                        <div class="fm-header-bar" style="float: right; margin-top: 20px; margin-bottom: 20px;">
                            <div class="fm-main">
                                <div class="row-fluid">

                                    <dt class="w2 pr" style="overflow: visible">

                                        <a href="" class='fm_popovercard' data-obj_id='1' data-url='get_card.php?id='>

                                             <img src="img/userface/image44.gif" alt="kiki1010" class="authorAreaImg">
                                        </a>

                                    </dt>

                                </div>
                            </div>
                            <br />
                        </div>

                        <div class="spaceholder"></div>

                        <!--作者信息-->
                        <!--signature-->
                        <!--签名档-->
                        <div id="Div2" class="authorSignature">
                            <p>
                                有些事，明知是错的，也要去坚持，因为不甘心；有些人，明知是爱的，也要去放弃，因为没结
                                  局；有时候，明知没路了，却还在前行，因为习惯了。
                            </p>
                        </div>
                        <!--signature-->
                    </div>
                    <!--************************************作者信息**********************-->

                    <td class="TableBody2" valign="top" width="*">

                     <?php echo $_smarty_tpl->getSubTemplate ("topicoperate.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>


                        <table border="0" width="98%" style="table-layout: fixed; word-break: break-all">
                            <tbody>
                                <tr>
                                    <div id="Div3">
                                        <h2>Re: 著名谣言和非谣言列表（已更新） </h2>
                                    </div>

                                    <br />
                                    <td width="100%" style="font-size: 9pt; line-height: 12pt; padding: 0px 5px;">
                                        <b><strong>发信人: ykxuewhu (我随心动★SWRH), 信区: WHU</strong></b>
                                        <br>
                                        <b><strong>发信站: 珞珈山水 (Mon Aug 31 09:09:59 2009), 站内</strong></b>
                                        <br>
                                        &nbsp;<br>
                                        姚明拒绝丰田广告能证伪吗？
                                <br>
                                        我看过一篇专访姚之队的报道
                                <br>
                                        他们在处理姚明代言的时候确实做了处理
                                <br>
                                        考虑到民族情绪
                                <br>
                                        日本方代言不接受
                                <br>
                                        由于丰田中心的关系
                                <br>
                                        toyota找姚明很正常吧
                                <br>
                                        广告单子不会小吧
                                <br>
                                        &nbsp;<br>
                                        【 在 DarkTemplar (树欲静而风不止，子欲养而亲不待) 的大作中提到: 】
                                <br>
                                        <font class="f006">: 1、被证明是谣言：</font>
                                        <br>
                                        <font class="f006">: &nbsp; （1)历史类</font>
                                        <br>
                                        <font class="f006">: 　　中国有个罗马村·谣言</font>
                                        <br>
                                        <font class="f006">: ...................</font>
                                        <br>
                                        &nbsp;<br>
                                        --
                                <br>
                                        来往的人们哪
                                <br>
                                        请将这话儿传唱
                                <br>
                                        我死之后哪
                                <br>
                                        葬我于那高高的上岗
                                <br>
                                        因为那里呀
                                <br>
                                        能看到我心爱的姑娘
                                <br>
                                        &nbsp;<br>
                                        &nbsp;<br>
                                        <font class="f000"></font><font class="f015" color="blue">※ 来源:·珞珈山水 bbs.whu.edu.cn·[FROM: 222.143.26.*]</font><font class="f000"> <br> </font></td>
                                </tr>
                            </tbody>
                        </table>
                    </td>

            </tr>

        </tbody>
    </table>

</div>



<?php echo '<script'; ?>
 src="js/jquery.popover.js"><?php echo '</script'; ?>
>

<?php echo '<script'; ?>
 type="text/javascript">
    $(function () {
        $('.fm_popovercard').each(function () {
            $(this).popovercard({
            });
        });
    });

<?php echo '</script'; ?>
>

<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>
<?php }} ?>
