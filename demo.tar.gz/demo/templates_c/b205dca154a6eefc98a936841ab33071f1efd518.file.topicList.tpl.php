<?php /* Smarty version Smarty-3.1.21-dev, created on 2014-12-22 13:56:35
         compiled from "./templates/topicList.tpl" */ ?>
<?php /*%%SmartyHeaderCode:17804965185497b2931b5779-23722689%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b205dca154a6eefc98a936841ab33071f1efd518' => 
    array (
      0 => './templates/topicList.tpl',
      1 => 1419227773,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '17804965185497b2931b5779-23722689',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5497b2931e21d9_01148596',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5497b2931e21d9_01148596')) {function content_5497b2931e21d9_01148596($_smarty_tpl) {?><?php  $_config = new Smarty_Internal_Config("test.conf", $_smarty_tpl->smarty, $_smarty_tpl);$_config->loadConfigVars("setup", 'local'); ?>
<?php echo $_smarty_tpl->getSubTemplate ("base.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('title'=>'foo'), 0);?>


<?php echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>



<?php echo $_smarty_tpl->getSubTemplate ("left.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>


<?php echo $_smarty_tpl->getSubTemplate ("right.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>



    <div class="votecontainer">


    <?php echo $_smarty_tpl->getSubTemplate ("ad.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

    
        <div id="cc-content">
            <ul class="cc-list">
                <li>
                    <div class="classItem">
                        <h2 class="name">
                            <a href="./disparticle.php">
                            大一新生
                            </a>
                        </h2>

                        <span class="badge">5</span>

                        <div class="leader">
                            <span>版主：</span> 
                            <a target="_blank" href="./dispuser.php" class="leader_img" title="么么哒" >
                                <img src="img/one.jpg" >
                            </a>
                        </div>
                        <div class="seq"></div>
                    </div>
                </li>

                <li>
                    <div class="classItem">

                        <h2 class="name">
                            <a href="./disparticle.php">
                            毕业生
                            </a>
                        </h2>

                        <span class="badge">14</span>

                        <div class="leader">
                            <span>版主：</span> 
                            <a target="_blank" href="./dispuser.php" class="leader_img" title="呵呵哒" >
                                <img src="img/two.jpg" >
                            </a>
                        </div>
                        <div class="seq"></div>
                    </div>
                </li>

                <li>
                    <div class="classItem">

                        <h2 class="name">
                            <a href="./disparticle.php">
                            珞珈金秋
                            </a>
                        </h2>

                        <span class="badge">14</span>

                        <div class="leader">
                            <span>版主：</span> 
                            <a target="_blank" href="./dispuser.php" class="leader_img" title="2哒" >
                                <img src="img/three.jpg" >
                            </a>
                        </div>
                        <div class="seq"></div>
                    </div>

                </li>

                <li>
                    <div class="classItem">

                        <h2 class="name">
                            <a href="./disparticle.php">
                            毕业生
                            </a>
                        </h2>

                        <span class="badge">14</span>

                        <div class="leader">
                            <span>版主：</span> 
                            <a target="_blank" href="./dispuser.php" class="leader_img" title="呵呵哒" >
                                <img src="img/two.jpg" >
                            </a>
                        </div>
                        <div class="seq"></div>
                    </div>
                </li>

                <li>
                    <div class="classItem">

                        <h2 class="name">
                            <a href="javascript:void(0);">
                            珞珈金秋
                            </a>
                        </h2>

                        <span class="badge">14</span>

                        <div class="leader">
                            <span>版主：</span> 
                            <a target="_blank" href="./dispuser.php" class="leader_img" title="2哒" >
                                <img src="img/three.jpg" >
                            </a>
                        </div>
                        <div class="seq"></div>
                    </div>

                </li>

                <li>
                    <div class="classItem">

                        <h2 class="name">
                            <a href="javascript:void(0);">
                            毕业生
                            </a>
                        </h2>

                        <span class="badge">14</span>

                        <div class="leader">
                            <span>版主：</span> 
                            <a target="_blank" href="./dispuser.php" class="leader_img" title="呵呵哒" >
                                <img src="img/two.jpg" >
                            </a>
                        </div>
                        <div class="seq"></div>
                    </div>
                </li>

                <li>
                    <div class="classItem">

                        <h2 class="name">
                            <a href="javascript:void(0);">
                            珞珈金秋
                            </a>
                        </h2>

                        <span class="badge">14</span>

                        <div class="leader">
                            <span>版主：</span> 
                            <a target="_blank" href="./dispuser.php" class="leader_img" title="2哒" >
                                <img src="img/three.jpg" >
                            </a>
                        </div>
                        <div class="seq"></div>
                    </div>

                </li>

                <li>
                    <div class="classItem">

                        <h2 class="name">
                            <a href="javascript:void(0);">
                            毕业生
                            </a>
                        </h2>

                        <span class="badge">14</span>

                        <div class="leader">
                            <span>版主：</span> 
                            <a target="_blank" href="./topicView.php" class="leader_img" title="呵呵哒" >
                                <img src="img/two.jpg" >
                            </a>
                        </div>
                        <div class="seq"></div>
                    </div>
                </li>

                <li>
                    <div class="classItem">

                        <h2 class="name">
                            <a href="javascript:void(0);">
                            珞珈金秋
                            </a>
                        </h2>

                        <span class="badge">14</span>

                        <div class="leader">
                            <span>版主：</span> 
                            <a target="_blank" href="./dispuser.php" class="leader_img" title="2哒" >
                                <img src="img/three.jpg" >
                            </a>
                        </div>
                        <div class="seq"></div>
                    </div>

                </li>

                <li>
                    <div class="classItem">

                        <h2 class="name">
                            <a href="javascript:void(0);">
                            毕业生
                            </a>
                        </h2>

                        <span class="badge">14</span>

                        <div class="leader">
                            <span>版主：</span> 
                            <a target="_blank" href="javascript:void(0);" class="leader_img" title="呵呵哒" >
                                <img src="img/two.jpg" >
                            </a>
                        </div>
                        <div class="seq"></div>
                    </div>
                </li>

                <li>
                    <div class="classItem">

                        <h2 class="name">
                            <a href="javascript:void(0);">
                            珞珈金秋
                            </a>
                        </h2>

                        <span class="badge">14</span>

                        <div class="leader">
                            <span>版主：</span> 
                            <a target="_blank" href="javascript:void(0);" class="leader_img" title="2哒" >
                                <img src="img/three.jpg" >
                            </a>
                        </div>
                        <div class="seq"></div>
                    </div>

                </li>

            </ul>
        </div>
    </div>

    <?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>
<?php }} ?>
