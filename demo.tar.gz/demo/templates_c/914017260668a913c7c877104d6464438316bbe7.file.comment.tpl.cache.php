<?php /* Smarty version Smarty-3.1.18, created on 2014-12-21 07:24:02
         compiled from ".\templates\comment.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2894954966782429355-32790525%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '914017260668a913c7c877104d6464438316bbe7' => 
    array (
      0 => '.\\templates\\comment.tpl',
      1 => 1419004584,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2894954966782429355-32790525',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_5496678242d1d2_53008344',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5496678242d1d2_53008344')) {function content_5496678242d1d2_53008344($_smarty_tpl) {?><div id="commentArea">
            <div id="commentHeader">
                
            </div>

            <div id="commentBody">
                
            </div>

            <div id="commentFooter">
                
            </div>
        </div>
    </div><?php }} ?>
