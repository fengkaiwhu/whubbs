<?php /* Smarty version Smarty-3.1.18, created on 2014-12-21 08:15:15
         compiled from ".\templates\navchild.tpl" */ ?>
<?php /*%%SmartyHeaderCode:31241549672b8402bf6-77547522%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '868e93b3ce301f1a13bba6c67f7bd1d6eddeadc7' => 
    array (
      0 => '.\\templates\\navchild.tpl',
      1 => 1419146112,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '31241549672b8402bf6-77547522',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_549672b8406a79_19710864',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_549672b8406a79_19710864')) {function content_549672b8406a79_19710864($_smarty_tpl) {?><table cellspacing="0" cellpadding="0" align="center" class="navClass2 table">
    <tbody>
        <tr>
            <td width="100%">
                <table width="100%" align="center" border="0" cellspacing="0" cellpadding="0">
                    <tbody>
                        <tr>
                            <td class="TopDarkNav" height="9"></td>
                        </tr>
                        <tr>
                            <td height="70" class="TopLighNav2">

                                <table border="0" width="100%" align="center">
                                    <tbody>
                                        <tr>
                                            <td align="left" width="10%"><a href="../wmainpage.php">
                                                <img border="0" src="img/pic/ws.jpg"></a></td>
                                            <td align="center" width="80%">
                                                <script src="/bbsad.js"></script>
                                                <script>showContentAd();</script>
                                                <a href="http://bbs.whu.edu.cn/indexpages/now/" target="_blank">
                                                    <img border="0" src="img/ad/ad.jpg"></a>
                                            </td>
                                          
                                        </tr>
                                    </tbody>
                                </table>

                            </td>
                        </tr>
                        <tr>
                            <td class="TopLighNav" height="9"></td>
                        </tr>
              
                    </tbody>
                </table>
            </td>
        </tr>
    </tbody>
</table>
<?php }} ?>
