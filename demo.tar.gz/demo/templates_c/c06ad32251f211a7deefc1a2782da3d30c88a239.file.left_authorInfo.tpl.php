<?php /* Smarty version Smarty-3.1.21-dev, created on 2014-12-19 19:26:15
         compiled from "./templates/left_authorInfo.tpl" */ ?>
<?php /*%%SmartyHeaderCode:135481364554940b57af5a83-29555255%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c06ad32251f211a7deefc1a2782da3d30c88a239' => 
    array (
      0 => './templates/left_authorInfo.tpl',
      1 => 1418987858,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '135481364554940b57af5a83-29555255',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_54940b57af7913_41795296',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_54940b57af7913_41795296')) {function content_54940b57af7913_41795296($_smarty_tpl) {?>  <div id="articleArea">

            <div id="authorArea">
           
              <div class="fm-header-bar" style="float: right;margin-top:60px;">
                <div class="fm-main">
                    <div class="row-fluid">
                        
                            <dt class="w2 pr" style="overflow:visible" >
                              
                                <a href="" class='fm_popovercard' data-obj_id='1' data-url='get_card.php?id='>
                    
                                <img src="img/two.jpg" alt="kiki1010" class="authorImg" >
                                </a>
                          
                            </dt>
                        
                    </div>
                </div>
            </div>
        
            
                <!--作者信息-->
                <div id="authorName">
                    <a target="_blank" href="javascript:void(0);" title="kiki1010" >
                        <h3>kiki1010</h3>
                    </a>
                </div>
                <div id="authorInfoc" class="authorInfoc" >
                    <span class="authorInfoc">
                        身份:<span>用户</span>
                    </span> 
                    <br />

                    <span class="authorInfoc">
                        等级:<span>一般站友</span>
                    </span>
                    <br />
                    <span class="authorInfoc">
                        星座: <span>狮子座</span>
                    </span>


                </div>
                <br />
                <!--签名档-->
                <div id="authorInfo">
                    <p>
                        有些事，明知是错的，也要去坚持，因为不甘心；有些人，明知是爱的，也要去放弃，因为没结
            局；有时候，明知没路了，却还在前行，因为习惯了。
                    </p>
                </div>
            </div>

            <div id="topicArea">
                <div id="topicTitle">
                    <h2>你遇见的事都是因你而生，你遇见的人都是为你而来（文/百无禁忌的理想）</h2>
                </div>

                <div id="topicTool">

                    <!-- 自适应效果 -->
                    <div id="auther">
                        <div id="authorImg"> 
                            <img src="img/two.jpg" >
                        </div>

                        <div id="authorName">
                            <a target="_blank" href="javascript:void(0);" title="kiki1010" >
                                <h3>kiki1010</h3>
                            </a>
                        </div>
                    </div><?php }} ?>
