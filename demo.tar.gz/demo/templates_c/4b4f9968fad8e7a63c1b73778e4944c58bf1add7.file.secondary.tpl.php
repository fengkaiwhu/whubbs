<?php /* Smarty version Smarty-3.1.21-dev, created on 2014-12-22 13:56:18
         compiled from "./templates/secondary.tpl" */ ?>
<?php /*%%SmartyHeaderCode:201547509854940b361bd212-66641605%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4b4f9968fad8e7a63c1b73778e4944c58bf1add7' => 
    array (
      0 => './templates/secondary.tpl',
      1 => 1419227773,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '201547509854940b361bd212-66641605',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_54940b361e6dd2_34323429',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_54940b361e6dd2_34323429')) {function content_54940b361e6dd2_34323429($_smarty_tpl) {?><?php  $_config = new Smarty_Internal_Config("test.conf", $_smarty_tpl->smarty, $_smarty_tpl);$_config->loadConfigVars("setup", 'local'); ?>
<?php echo $_smarty_tpl->getSubTemplate ("base.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array('title'=>'foo'), 0);?>


<?php echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>



<?php echo $_smarty_tpl->getSubTemplate ("left.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>


<?php echo $_smarty_tpl->getSubTemplate ("right.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>


<div class="erjilogo">
            <img src="img/erjilogo.png" />
 </div>

<div class="secondarycontainer">
    <!--
        <div class="col-xs-12"> 
            <div class="disradio">
            <input type="radio" name="student" value="图片模式" checked="checked" />图片模式
            <input type="radio" name="teacher" value="列表模式" />列表模式
            </div>
        </div>
        
        <div class="col-xs-4t contentlittle">
           <div class="alignmid"> <img src="img/erji.jpg" /></div>
           
        </div>

        
        <div class="col-xs-4t contentlittle">
           <div class="alignmid"> <img src="img/erji.jpg" /></div>
           
        </div>

      
        <div class="col-xs-4t contentlittle">
           <div class="alignmid"> <img src="img/erji.jpg" /></div>
           
        </div>
        <br />
        -->
       <!--
        <div class="col-xs-4t contentlittle">
           <div class="alignmid"> <img src="img/erji.jpg" /></div>
           
        </div>

       
        <div class="col-xs-4t contentlittle">
           <div class="alignmid"> <img src="img/erji.jpg" /></div>
           
        </div>

        
        <div class="col-xs-4t contentlittle">
           <div class="alignmid"> <img src="img/erji.jpg" /></div>
           
        </div>
        <br />
        -->
        <!--
        <div class="col-xs-4t contentlittle">
           <div class="alignmid"> <img src="img/erji.jpg" /></div>
           
        </div>
          
        <div class="col-xs-4t contentlittle">
           <div class="alignmid"> <img src="img/erji.jpg" /></div>
           
        </div>
        
        <div class="col-xs-4t contentlittle">
           <div class="alignmid"> <img src="img/erji.jpg" /></div>
           
        </div>
        -->

        <div class="row ">
          <div class="col-sm-6 col-md-4 ">
            <div class="thumbnail">
              <img data-src="holder.js/300x300" alt="..." src="img/2.jpg">
              <div class="caption">
                <h3>大一新生</h3>
                <p>...</p>
                <p><a href="./board.php" class="btn btn-primary" role="button">进入版面</a></p>
              </div>
            </div>
          </div>

         <div class="col-sm-6 col-md-4 ">
            <div class="thumbnail">
              <img data-src="holder.js/300x300" alt="..." src="img/3.jpg">
              <div class="caption">
                <h3>毕业之声</h3>
                <p>...</p>
                <p><a href="./board.php" class="btn btn-primary" role="button">进入版面</a></p>
              </div>
            </div>
          </div>

          <div class="col-sm-6 col-md-4 ">
            <div class="thumbnail">
              <img data-src="holder.js/300x300" alt="..." src="img/1.jpg">
              <div class="caption">
                <h3>武大附中</h3>
                <p>...</p>
                <p><a href="./board.php" class="btn btn-primary" role="button">进入版面</a></p>
              </div>
            </div>
          </div> 
          
          <div class="col-sm-6 col-md-4 ">
            <div class="thumbnail">
              <img data-src="holder.js/300x300" alt="..." src="img/3.jpg">
              <div class="caption">
                <h3>珞珈山水</h3>
                <p>...</p>
                <p><a href="./board.php" class="btn btn-primary" role="button">进入版面</a></p>
              </div>
            </div>
          </div> 

          <div class="col-sm-6 col-md-4 ">
            <div class="thumbnail">
              <img data-src="holder.js/300x300" alt="..." src="img/2.jpg">
              <div class="caption">
                <h3>科学技术</h3>
                <p>...</p>
                <p><a href="./board.php" class="btn btn-primary" role="button">进入版面</a></p>
              </div>
            </div>
          </div> 

          <div class="col-sm-6 col-md-4 ">
            <div class="thumbnail">
              <img data-src="holder.js/300x300" alt="..." src="img/1.jpg">
              <div class="caption">
                <h3>文学艺术</h3>
                <p>...</p>
                <p><a href="./board.php" class="btn btn-primary" role="button">进入版面</a></p>
              </div>
            </div>
          </div> 

          <div class="col-sm-6 col-md-4 ">
            <div class="thumbnail">
              <img data-src="holder.js/300x300" alt="..." src="img/3.jpg">
              <div class="caption">
                <h3>休闲娱乐</h3>
                <p>...</p>
                <p><a href="#" class="btn btn-primary" role="button">进入版面</a></p>
              </div>
            </div>
          </div> 


          <div class="col-sm-6 col-md-4 ">
            <div class="thumbnail">
              <img data-src="holder.js/300x300" alt="..." src="img/2.jpg">
              <div class="caption">
                <h3>体育健身</h3>
                <p>...</p>
                <p><a href="#" class="btn btn-primary" role="button">进入版面</a></p>
              </div>
            </div>
          </div> 


          <div class="col-sm-6 col-md-4 ">
            <div class="thumbnail">
              <img data-src="holder.js/300x300" alt="..." src="img/1.jpg">
              <div class="caption">
                <h3>社会信息</h3>
                <p>...</p>
                <p><a href="#" class="btn btn-primary" role="button">进入版面</a></p>
              </div>
            </div>
          </div> 


        
        <!--end Row-->
        </div>


<!--end Secondary-->
</div>





<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

<?php }} ?>
