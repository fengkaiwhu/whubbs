<?php /* Smarty version Smarty-3.1.21-dev, created on 2014-12-22 13:58:13
         compiled from "./templates/topicoperate.tpl" */ ?>
<?php /*%%SmartyHeaderCode:13044738695497b2f56e2b15-62052058%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '25490364031ca4bc5fd23a65d6f8ced0938e8c01' => 
    array (
      0 => './templates/topicoperate.tpl',
      1 => 1419227690,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '13044738695497b2f56e2b15-62052058',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5497b2f56e4ad9_00710387',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5497b2f56e4ad9_00710387')) {function content_5497b2f56e4ad9_00710387($_smarty_tpl) {?>            <table width="100%">
                            <tbody>
                                <tr>
                                    <td width="*">
                                        <a href="queryresult.php?userid=DarkTemplar&amp;boardNames=WHU">
                                            <img src="img/pic/find.gif" border="0" title="搜索DarkTemplar在本版的所有贴子">
                                        </a>&nbsp;
                                        <a href="sendmail.php?board=WHU&amp;reID=1105563173">
                                            <img title="点击这里发送信件给DarkTemplar" border="0" src="img/pic/email.gif">
                                        </a>&nbsp;
                                        <a href="editarticle.php?board=WHU&amp;reID=1105563173">
                                            <img src="img/pic/edit.gif" border="0" title="编辑"></a>&nbsp;

                                        <a href="deletearticle.php?board=WHU&amp;ID=1105563173" onclick="return confirm('你真的要删除本文吗?')">
                                            <img src="img/pic/delete.gif" border="0" title="删除"></a>&nbsp;
                                        <a href="postarticle.php?board=WHU&amp;reID=1105563173">
                                            <img src="img/pic/reply_a.gif" border="0" title="回复这个贴子">
                                        </a>
                                        &nbsp;
                                        <a href="postarticle.php?board=WHU&amp;reID=1105618537">
                                            <img src="img/57.gif" border="0" title="收藏贴子">
                                        </a>
                                        &nbsp;
                                        <a href="postarticle.php?board=WHU&amp;reID=1105618537">
                                            <img src="img/52.gif" border="0" title="收藏贴子">
                                        </a>

                                    </td>
                                    <td width="50">
                                        <b>楼主</b></td>
                                </tr>
                                <tr>
                                    <td bgcolor="#D8C0B1" height="1" colspan="2"></td>
                                </tr>
                            </tbody>
                        </table>
<?php }} ?>
