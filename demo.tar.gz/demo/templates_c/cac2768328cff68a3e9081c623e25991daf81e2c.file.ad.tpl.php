<?php /* Smarty version Smarty-3.1.21-dev, created on 2014-12-22 13:56:35
         compiled from "./templates/ad.tpl" */ ?>
<?php /*%%SmartyHeaderCode:4611977245497a970eedf26-97427592%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'cac2768328cff68a3e9081c623e25991daf81e2c' => 
    array (
      0 => './templates/ad.tpl',
      1 => 1419227773,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '4611977245497a970eedf26-97427592',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5497a970eefa77_54245357',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5497a970eefa77_54245357')) {function content_5497a970eefa77_54245357($_smarty_tpl) {?><table cellspacing="0" cellpadding="0" align="center" class="navClass2 table">
    <tbody>
        <tr>
            <td width="100%">
                <table width="100%" align="center" border="0" cellspacing="0" cellpadding="0">
                    <tbody>
                        <tr>
                            <td class="TopDarkNav" height="9"></td>
                        </tr>
                        <tr>
                            <td height="70" class="TopLighNav2">

                                <table border="0" width="100%" align="center">
                                    <tbody>
                                        <tr>
                                            <td align="left" width="10%"><a href="./index.php">
                                                <img border="0" src="img/pic/ws.jpg"></a></td>
                                            <td align="center" width="80%">
                                                <?php echo '<script'; ?>
 src="/bbsad.js"><?php echo '</script'; ?>
>
                                                <?php echo '<script'; ?>
>showContentAd();<?php echo '</script'; ?>
>
                                                <a href="http://bbs.whu.edu.cn/indexpages/now/" target="_blank">
                                                    <img border="0" src="img/ad/ad.jpg"></a>
                                            </td>
                                          
                                        </tr>
                                    </tbody>
                                </table>

                            </td>
                        </tr>
                        <tr>
                            <td class="TopLighNav" height="9"></td>
                        </tr>
              
                    </tbody>
                </table>
            </td>
        </tr>
    </tbody>
</table>
<?php }} ?>
