<?php /* Smarty version Smarty-3.1.18, created on 2014-12-29 04:37:55
         compiled from ".\templates\indexshow.tpl" */ ?>
<?php /*%%SmartyHeaderCode:4505548850c5b2f368-72065127%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '262bc2f138d93a287bd4eb14f9a55b85db2f0b06' => 
    array (
      0 => '.\\templates\\indexshow.tpl',
      1 => 1419824268,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '4505548850c5b2f368-72065127',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_548850c5b81403_68146080',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_548850c5b81403_68146080')) {function content_548850c5b81403_68146080($_smarty_tpl) {?>
<div class="mcontainer" id="index-content-bottom">
    <!-- container begin-->
				
	<div class="wrapper index-content-wrapper"  id="indexshow">
    	<div class="bottom">
    		<div class="inner-wrapper" >
    			<div class="stories">
    				<div class="reps clearfix" id="reps">

   						<a target="_blank" href="./board.php" class="rep current repspecial" id="foucs_tab_1" data-type="topic" data-token="" title="十大热帖">
						    <span class="info-card">十大话题</span>
						    <img src="img/one.jpg" >
						</a>

					    <a target="_blank" href="./board.php" class="rep repspecial" id="foucs_tab_2" data-type="topic" data-token="" title="推荐版面" >
					    	<span class="info-card">推荐文章</span>
					 		<img src="img/two.jpg" >
					    </a>

					    <a target="_blank" href="./board.php" class="rep repspecial" id="foucs_tab_3" data-type="topic" data-token="" title="体育健身">
					    	<span class="info-card">今日新帖</span>
					        <img src="img/three.jpg" >
					    </a>


					    <a target="_blank" href="./secondary.php" class="rep" id="foucs_tab_4" data-type="topic" data-token="" title="文学艺术">
					    	<span class="info-card">信息天地</span>
					    	<img src="img/four.jpg" >
					    </a>

					    <a target="_blank" href="./secondary.php" class="rep" id="foucs_tab_5" data-type="topic" data-token="" title="本站系统">
					    	<span class="info-card">学习考试</span>
					    	<img src="img/five.jpg" >
					    </a>

					    <a target="_blank" href="./secondary.php" class="rep" id="foucs_tab_6" data-type="topic" data-token="" title="武汉大学">
					    	<span class="info-card">本站系统</span>
					    	<img src="img/eight.jpg" >
					    </a>

					    <a target="_blank" href="./secondary.php" class="rep" id="foucs_tab_7" data-type="topic" data-token="" title="电脑网络">
					    	<span class="info-card">文学艺术</span>
							<img src="img/seven.jpg" >
					    </a>

					    <a target="_blank" href="./secondary.php" class="rep" id="foucs_tab_8" data-type="topic" data-token="" title="社会信息">
					    	<span class="info-card">武汉大学 </span>
							<img src="img/six.jpg" >
					    </a>

					    <a target="_blank" href="./secondary.php" class="rep" id="foucs_tab_9" data-type="topic" data-token="" title="科学技术">
					    	<span class="info-card"> 体育健身</span>
					  		<img src="img/night.jpg" >
					    </a>


					     <a target="_blank" href="./secondary.php" class="rep" id="foucs_tab_10" data-type="topic" data-token="" title="电脑网络">
					    	<span class="info-card">知性感性 </span>
							<img src="img/seven.jpg" >
					    </a>

					    <a target="_blank" href="./secondary.php" class="rep" id="foucs_tab_11" data-type="topic" data-token="" title="社会信息">
					    	<span class="info-card">休闲娱乐</span>
							<img src="img/eight.jpg" >
					    </a>

					    <a target="_blank" href="./secondary.php" class="rep" id="foucs_tab_12" data-type="topic" data-token="" title="科学技术">
					    	<span class="info-card">生活时尚</span>
					  		<img src="img/night.jpg" >
					    </a>

					   
    				</div>

					<!--右栏重复出现12次，-->

    				<div class="single-story" id="foucs_con_1">
		 	 			<div class="single-story-inner">
		    				<img class="author-img" src="img/one.jpg">
		    				<div class="story-title">
		    					<div>
		    						<a class="name" href="./board.php" target="_blank">十大话题</a>
		    					</div>
								<div>
									<span class="whitespacen">
										<br />
									</span>
								</div>

							</div>

						    <div class="sep"></div>
							<div class="story-content">
							  
							    <div class="story-content-answer">
								    <span class="vote">
								    	526
								    </span>
								     <p>
								     <a class="question_link" target="_blank" href="./disparticle.php">
								     	吐槽一下本期跑男
								     </a>
									<a href="./board.php">
										[武大特快]
									</a>
								     </p>
							    </div>
							  
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p>
								    <a class="question_link" target="_blank" href="./disparticle.php">冬至日，你吃饺子了吗？
								    </a>
									<a href="./board.php">
										[武大特快]
									</a>
								    </p>
							    </div>
							    
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p>
								    <a class="question_link" target="_blank" href="./disparticle.php">年终了，大家评评哪个武大哪个食堂最差？哪个食堂最好？
								    </a>
									<a href="./board.php">
										[武大特快]
									</a>
								    </p>
							    </div>
							   
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p>
								    <a class="question_link" target="_blank" href="./disparticle.php">冬至日，你吃饺子了吗？
								    </a>
									<a href="./board.php">
										[武大特快]
									</a>
								    </p>
							    </div>
							    
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p>
								    <a class="question_link" target="_blank" href="./disparticle.php">本人武大校友，想在武大附近租房，求收留。妹子当然最好啦
								    </a>
									<a href="./board.php">
										[房屋租赁]
									</a>
								    </p>
							    </div>
						    </div>
						 
						</div>
		    		</div>

		    		<div class="single-story undisplay" id="foucs_con_2">
		 	 			<div class="single-story-inner">
		    				<img class="author-img" src="img/two.jpg">
		    						<div class="story-title">
		    					<div>
		    						<a class="name" href="./board.php" target="_blank">推荐文章</a>
		    					</div>
								<div>
									<span class="whitespacen">
										<br />
									</span>
								</div>

							</div>

						    <div class="sep"></div>
							<div class="story-content">
							  
							    <div class="story-content-answer">
								    <span class="vote">
								    	526
								    </span>
								     <p>
								     <a class="question_link" target="_blank" href="./disparticle.php">
								     	吐槽一下本期跑男
								     </a>
									<a href="./board.php">
										[武大特快]
									</a>
								     </p>
							    </div>
							  
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p>
								    <a class="question_link" target="_blank" href="./disparticle.php">冬至日，你吃饺子了吗？
								    </a>
									<a href="./board.php">
										[武大特快]
									</a>
								    </p>
							    </div>
							    
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p>
								    <a class="question_link" target="_blank" href="./disparticle.php">年终了，大家评评哪个武大哪个食堂最差？哪个食堂最好？
								    </a>
									<a href="./board.php">
										[武大特快]
									</a>
								    </p>
							    </div>
							   
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p>
								    <a class="question_link" target="_blank" href="./disparticle.php">冬至日，你吃饺子了吗？
								    </a>
									<a href="./board.php">
										[武大特快]
									</a>
								    </p>
							    </div>
							    
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p>
								    <a class="question_link" target="_blank" href="./disparticle.php">本人武大校友，想在武大附近租房，求收留。妹子当然最好啦
								    </a>
									<a href="./board.php">
										[房屋租赁]
									</a>
								    </p>
							    </div>
						    </div>
						</div>
		    		</div>

		    		<div class="single-story undisplay" id="foucs_con_3">
		 	 			<div class="single-story-inner">
		    				<img class="author-img" src="img/three.jpg">
		    						<div class="story-title">
		    					<div>
		    						<a class="name" href="./board.php" target="_blank">今日新帖</a>
		    					</div>
								<div>
									<span class="whitespacen">
										<br />
									</span>
								</div>

							</div>

						    <div class="sep"></div>
							<div class="story-content">
							  
							    <div class="story-content-answer">
								    <span class="vote">
								    	526
								    </span>
								     <p>
								     <a class="question_link" target="_blank" href="./disparticle.php">
								     	吐槽一下本期跑男
								     </a>
									<a href="./board.php">
										[武大特快]
									</a>
								     </p>
							    </div>
							  
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p>
								    <a class="question_link" target="_blank" href="./disparticle.php">冬至日，你吃饺子了吗？
								    </a>
									<a href="./board.php">
										[武大特快]
									</a>
								    </p>
							    </div>
							    
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p>
								    <a class="question_link" target="_blank" href="./disparticle.php">年终了，大家评评哪个武大哪个食堂最差？哪个食堂最好？
								    </a>
									<a href="./board.php">
										[武大特快]
									</a>
								    </p>
							    </div>
							   
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p>
								    <a class="question_link" target="_blank" href="./disparticle.php">冬至日，你吃饺子了吗？
								    </a>
									<a href="./board.php">
										[武大特快]
									</a>
								    </p>
							    </div>
							    
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p>
								    <a class="question_link" target="_blank" href="./disparticle.php">本人武大校友，想在武大附近租房，求收留。妹子当然最好啦
								    </a>
									<a href="./board.php">
										[房屋租赁]
									</a>

								    </p>
							    </div>
						    </div>
						</div>
		    		</div>

		    		<div class="single-story undisplay" id="foucs_con_4">
		 	 			<div class="single-story-inner">
		    				<img class="author-img" src="img/four.jpg">
		    						<div class="story-title">
		    					<div>
		    						<a class="name" href="" target="_blank">信息天地</a>
		    					</div>
								<div>
									<span class="whitespacen">
										<br />
									</span>
								</div>

							</div>

						    <div class="sep"></div>
							<div class="story-content">
							  
							    <div class="story-content-answer">
								    <span class="vote">
								    	526
								    </span>
								     <p>
								     <a class="question_link" target="_blank" href="./disparticle.php">
								     	吐槽一下本期跑男
								     </a>
									<a href="./board.php">
										[武大特快]
									</a>
								     </p>
							    </div>
							  
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p>
								    <a class="question_link" target="_blank" href="./disparticle.php">冬至日，你吃饺子了吗？
								    </a>
									<a href="./board.php">
										[武大特快]
									</a>
								    </p>
							    </div>
							    
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p>
								    <a class="question_link" target="_blank" href="./disparticle.php">年终了，大家评评哪个武大哪个食堂最差？哪个食堂最好？
								    </a>
									<a href="./board.php">
										[武大特快]
									</a>
								    </p>
							    </div>
							   
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p>
								    <a class="question_link" target="_blank" href="./disparticle.php">冬至日，你吃饺子了吗？
								    </a>
									<a href="./board.php">
										[武大特快]
									</a>
								    </p>
							    </div>
							    
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p>
								    <a class="question_link" target="_blank" href="./disparticle.php">本人武大校友，想在武大附近租房，求收留。妹子当然最好啦
								    </a>
									<a href="./board.php">
										[房屋租赁]
									</a>
								    </p>
							    </div>
						    </div>
						</div>
		    		</div>

		    		<div class="single-story undisplay" id="foucs_con_5">
		 	 			<div class="single-story-inner">
		    				<img class="author-img" src="img/five.jpg">
		    					<div class="story-title">
		    					<div>
		    						<a class="name" href="" target="_blank">学习考试</a>
		    					</div>
								<div>
									<span class="whitespacen">
										<br />
									</span>
								</div>

							</div>

						    <div class="sep"></div>
							<div class="story-content">
							  
							    <div class="story-content-answer">
								    <span class="vote">
								    	526
								    </span>
								     <p>
								     <a class="question_link" target="_blank" href="./disparticle.php">
								     	吐槽一下本期跑男
								     </a>
									<a href="./board.php">
										[武大特快]
									</a>
								     </p>
							    </div>
							  
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p>
								    <a class="question_link" target="_blank" href="./disparticle.php">冬至日，你吃饺子了吗？
								    </a>
									<a href="./board.php">
										[武大特快]
									</a>
								    </p>
							    </div>
							    
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p>
								    <a class="question_link" target="_blank" href="./disparticle.php">年终了，大家评评哪个武大哪个食堂最差？哪个食堂最好？
								    </a>
									<a href="./board.php">
										[武大特快]
									</a>
								    </p>
							    </div>
							   
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p>
								    <a class="question_link" target="_blank" href="./disparticle.php">冬至日，你吃饺子了吗？
								    </a>
									<a href="./board.php">
										[武大特快]
									</a>
								    </p>
							    </div>
							    
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p>
								    <a class="question_link" target="_blank" href="./disparticle.php">本人武大校友，想在武大附近租房，求收留。妹子当然最好啦
								    </a>
									<a href="./board.php">
										[房屋租赁]
									</a>
								    </p>
							    </div>
						    </div>
						</div>
		    		</div>

		    		<div class="single-story undisplay" id="foucs_con_6">
		 	 			<div class="single-story-inner">
		    				<img class="author-img" src="img/six.jpg">
		    						<div class="story-title">
		    					<div>
		    						<a class="name" href="" target="_blank">本站系统</a>
		    					</div>
								<div>
									<span class="whitespacen">
										<br />
									</span>
								</div>

							</div>

						    <div class="sep"></div>
							<div class="story-content">
							  
							    <div class="story-content-answer">
								    <span class="vote">
								    	526
								    </span>
								     <p>
								     <a class="question_link" target="_blank" href="./disparticle.php">
								     	吐槽一下本期跑男
								     </a>
									<a href="./board.php">
										[武大特快]
									</a>
								     </p>
							    </div>
							  
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p>
								    <a class="question_link" target="_blank" href="./disparticle.php">冬至日，你吃饺子了吗？
								    </a>
									<a href="./board.php">
										[武大特快]
									</a>
								    </p>
							    </div>
							    
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p>
								    <a class="question_link" target="_blank" href="./disparticle.php">年终了，大家评评哪个武大哪个食堂最差？哪个食堂最好？
								    </a>
									<a href="./board.php">
										[武大特快]
									</a>
								    </p>
							    </div>
							   
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p>
								    <a class="question_link" target="_blank" href="./disparticle.php">冬至日，你吃饺子了吗？
								    </a>
									<a href="./board.php">
										[武大特快]
									</a>
								    </p>
							    </div>
							    
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p>
								    <a class="question_link" target="_blank" href="./disparticle.php">本人武大校友，想在武大附近租房，求收留。妹子当然最好啦
								    </a>
									<a href="./board.php">
										[房屋租赁]
									</a>
								    </p>
							    </div>
						    </div>
						</div>
		    		</div>

		    		<div class="single-story undisplay" id="foucs_con_7">
		 	 			<div class="single-story-inner">
		    				<img class="author-img" src="img/seven.jpg">
		    						<div class="story-title">
		    					<div>
		    						<a class="name" href="" target="_blank">文学艺术</a>
		    					</div>
								<div>
									<span class="whitespacen">
										<br />
									</span>
								</div>

							</div>

						    <div class="sep"></div>
							<div class="story-content">
							  
							    <div class="story-content-answer">
								    <span class="vote">
								    	526
								    </span>
								     <p>
								     <a class="question_link" target="_blank" href="./disparticle.php">
								     	吐槽一下本期跑男
								     </a>
									<a href="./board.php">
										[武大特快]
									</a>
								     </p>
							    </div>
							  
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p>
								    <a class="question_link" target="_blank" href="./disparticle.php">冬至日，你吃饺子了吗？
								    </a>
									<a href="./board.php">
										[武大特快]
									</a>
								    </p>
							    </div>
							    
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p>
								    <a class="question_link" target="_blank" href="./disparticle.php">年终了，大家评评哪个武大哪个食堂最差？哪个食堂最好？
								    </a>
									<a href="./board.php">
										[武大特快]
									</a>
								    </p>
							    </div>
							   
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p>
								    <a class="question_link" target="_blank" href="./disparticle.php">冬至日，你吃饺子了吗？
								    </a>
									<a href="./board.php">
										[武大特快]
									</a>
								    </p>
							    </div>
							    
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p>
								    <a class="question_link" target="_blank" href="./disparticle.php">本人武大校友，想在武大附近租房，求收留。妹子当然最好啦
								    </a>
									<a href="./board.php">
										[房屋租赁]
									</a>
								    </p>
							    </div>
						    </div>
						</div>
		    		</div>

		    		<div class="single-story undisplay" id="foucs_con_8">
		 	 			<div class="single-story-inner">
		    				<img class="author-img" src="img/six.jpg">
		    						<div class="story-title">
		    					<div>
		    						<a class="name" href="" target="_blank">武汉大学</a>
		    					</div>
								<div>
									<span class="whitespacen">
										<br />
									</span>
								</div>

							</div>

						    <div class="sep"></div>
							<div class="story-content">
							  
							    <div class="story-content-answer">
								    <span class="vote">
								    	526
								    </span>
								     <p>
								     <a class="question_link" target="_blank" href="./disparticle.php">
								     	吐槽一下本期跑男
								     </a>
									<a href="./board.php">
										[武大特快]
									</a>
								     </p>
							    </div>
							  
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p>
								    <a class="question_link" target="_blank" href="./disparticle.php">冬至日，你吃饺子了吗？
								    </a>
									<a href="./board.php">
										[武大特快]
									</a>
								    </p>
							    </div>
							    
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p>
								    <a class="question_link" target="_blank" href="./disparticle.php">年终了，大家评评哪个武大哪个食堂最差？哪个食堂最好？
								    </a>
									<a href="./board.php">
										[武大特快]
									</a>
								    </p>
							    </div>
							   
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p>
								    <a class="question_link" target="_blank" href="./disparticle.php">冬至日，你吃饺子了吗？
								    </a>
									<a href="./board.php">
										[武大特快]
									</a>
								    </p>
							    </div>
							    
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p>
								    <a class="question_link" target="_blank" href="./disparticle.php">本人武大校友，想在武大附近租房，求收留。妹子当然最好啦
								    </a>
									<a href="./board.php">
										[房屋租赁]
									</a>
								    </p>
							    </div>
						    </div>
						</div>
		    		</div>

		    		<div class="single-story undisplay" id="foucs_con_9">
		 	 			<div class="single-story-inner">
		    				<img class="author-img" src="img/night.jpg">
		    						<div class="story-title">
		    					<div>
		    						<a class="name" href="" target="_blank">体育健身</a>
		    					</div>
								<div>
									<span class="whitespacen">
										<br />
									</span>
								</div>

							</div>

						    <div class="sep"></div>
							<div class="story-content">
							  
							    <div class="story-content-answer">
								    <span class="vote">
								    	526
								    </span>
								     <p>
								     <a class="question_link" target="_blank" href="./disparticle.php">
								     	吐槽一下本期跑男
								     </a>
									<a href="./board.php">
										[武大特快]
									</a>
								     </p>
							    </div>
							  
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p>
								    <a class="question_link" target="_blank" href="./disparticle.php">冬至日，你吃饺子了吗？
								    </a>
									<a href="./board.php">
										[武大特快]
									</a>
								    </p>
							    </div>
							    
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p>
								    <a class="question_link" target="_blank" href="./disparticle.php">年终了，大家评评哪个武大哪个食堂最差？哪个食堂最好？
								    </a>
									<a href="./board.php">
										[武大特快]
									</a>
								    </p>
							    </div>
							   
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p>
								    <a class="question_link" target="_blank" href="./disparticle.php">冬至日，你吃饺子了吗？
								    </a>
									<a href="./board.php">
										[武大特快]
									</a>
								    </p>
							    </div>
							    
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p>
								    <a class="question_link" target="_blank" href="./disparticle.php">本人武大校友，想在武大附近租房，求收留。妹子当然最好啦
								    </a>
									<a href="./board.php">
										[房屋租赁]
									</a>
								    </p>
							    </div>
						    </div>
						</div>
		    		</div>


		    			<div class="single-story undisplay" id="foucs_con_10">
		 	 			<div class="single-story-inner">
		    				<img class="author-img" src="img/night.jpg">
		    						<div class="story-title">
		    					<div>
		    						<a class="name" href="" target="_blank">知性感性</a>
		    					</div>
								<div>
									<span class="whitespacen">
										<br />
									</span>
								</div>

							</div>

						    <div class="sep"></div>
							<div class="story-content">
							  
							    <div class="story-content-answer">
								    <span class="vote">
								    	526
								    </span>
								     <p>
								     <a class="question_link" target="_blank" href="./disparticle.php">
								     	吐槽一下本期跑男
								     </a>
									<a href="./board.php">
										[武大特快]
									</a>
								     </p>
							    </div>
							  
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p>
								    <a class="question_link" target="_blank" href="./disparticle.php">冬至日，你吃饺子了吗？
								    </a>
									<a href="./board.php">
										[武大特快]
									</a>
								    </p>
							    </div>
							    
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p>
								    <a class="question_link" target="_blank" href="./disparticle.php">年终了，大家评评哪个武大哪个食堂最差？哪个食堂最好？
								    </a>
									<a href="./board.php">
										[武大特快]
									</a>
								    </p>
							    </div>
							   
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p>
								    <a class="question_link" target="_blank" href="./disparticle.php">冬至日，你吃饺子了吗？
								    </a>
									<a href="./board.php">
										[武大特快]
									</a>
								    </p>
							    </div>
							    
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p>
								    <a class="question_link" target="_blank" href="./disparticle.php">本人武大校友，想在武大附近租房，求收留。妹子当然最好啦
								    </a>
									<a href="./board.php">
										[房屋租赁]
									</a>
								    </p>
							    </div>
						    </div>
						</div>
		    		</div>

				

					<div class="single-story undisplay" id="foucs_con_11">
		 	 			<div class="single-story-inner">
		    				<img class="author-img" src="img/night.jpg">
		    						<div class="story-title">
		    					<div>
		    						<a class="name" href="" target="_blank">休闲娱乐</a>
		    					</div>
								<div>
									<span class="whitespacen">
										<br />
									</span>
								</div>

							</div>

						    <div class="sep"></div>
							<div class="story-content">
							  
							    <div class="story-content-answer">
								    <span class="vote">
								    	526
								    </span>
								     <p>
								     <a class="question_link" target="_blank" href="./disparticle.php">
								     	吐槽一下本期跑男
								     </a>
									<a href="./board.php">
										[武大特快]
									</a>
								     </p>
							    </div>
							  
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p>
								    <a class="question_link" target="_blank" href="./disparticle.php">冬至日，你吃饺子了吗？
								    </a>
									<a href="./board.php">
										[武大特快]
									</a>
								    </p>
							    </div>
							    
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p>
								    <a class="question_link" target="_blank" href="./disparticle.php">年终了，大家评评哪个武大哪个食堂最差？哪个食堂最好？
								    </a>
									<a href="./board.php">
										[武大特快]
									</a>
								    </p>
							    </div>
							   
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p>
								    <a class="question_link" target="_blank" href="./disparticle.php">冬至日，你吃饺子了吗？
								    </a>
									<a href="./board.php">
										[武大特快]
									</a>
								    </p>
							    </div>
							    
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p>
								    <a class="question_link" target="_blank" href="./disparticle.php">本人武大校友，想在武大附近租房，求收留。妹子当然最好啦
								    </a>
									<a href="./board.php">
										[房屋租赁]
									</a>
								    </p>
							    </div>
						    </div>
						</div>
		    		</div>


					<div class="single-story undisplay" id="foucs_con_12">
		 	 			<div class="single-story-inner">
		    				<img class="author-img" src="img/night.jpg">
		    						<div class="story-title">
		    					<div>
		    						<a class="name" href="" target="_blank">生活时尚</a>
		    					</div>
								<div>
									<span class="whitespacen">
										<br />
									</span>
								</div>

							</div>

						    <div class="sep"></div>
							<div class="story-content">
							  
							    <div class="story-content-answer">
								    <span class="vote">
								    	526
								    </span>
								     <p>
								     <a class="question_link" target="_blank" href="./disparticle.php">
								     	吐槽一下本期跑男
								     </a>
									<a href="./board.php">
										[武大特快]
									</a>
								     </p>
							    </div>
							  
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p>
								    <a class="question_link" target="_blank" href="./disparticle.php">冬至日，你吃饺子了吗？
								    </a>
									<a href="./board.php">
										[武大特快]
									</a>
								    </p>
							    </div>
							    
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p>
								    <a class="question_link" target="_blank" href="./disparticle.php">年终了，大家评评哪个武大哪个食堂最差？哪个食堂最好？
								    </a>
									<a href="./board.php">
										[武大特快]
									</a>
								    </p>
							    </div>
							   
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p>
								    <a class="question_link" target="_blank" href="./disparticle.php">冬至日，你吃饺子了吗？
								    </a>
									<a href="./board.php">
										[武大特快]
									</a>
								    </p>
							    </div>
							    
							    <div class="story-content-answer">
								    <span class="vote">
								    	551
								    </span>
								    <p>
								    <a class="question_link" target="_blank" href="./disparticle.php">本人武大校友，想在武大附近租房，求收留。妹子当然最好啦
								    </a>
									<a href="./board.php">
										[房屋租赁]
									</a>
								    </p>
							    </div>
						    </div>
						</div>
		    		</div>

		  		<!--*****************-->
				</div>
			</div>
		</div>

<!--Container and wrapper-->
	</div>
</div>
<?php }} ?>
