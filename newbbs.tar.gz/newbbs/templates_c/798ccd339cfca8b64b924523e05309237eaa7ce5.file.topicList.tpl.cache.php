<?php /* Smarty version Smarty-3.1.18, created on 2014-12-24 13:55:24
         compiled from ".\templates\topicList.tpl" */ ?>
<?php /*%%SmartyHeaderCode:3235554967ab8330573-01147672%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '798ccd339cfca8b64b924523e05309237eaa7ce5' => 
    array (
      0 => '.\\templates\\topicList.tpl',
      1 => 1419423551,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3235554967ab8330573-01147672',
  'function' => 
  array (
  ),
  'cache_lifetime' => 120,
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_54967ab8372c01_71045065',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_54967ab8372c01_71045065')) {function content_54967ab8372c01_71045065($_smarty_tpl) {?><?php  $_config = new Smarty_Internal_Config("test.conf", $_smarty_tpl->smarty, $_smarty_tpl);$_config->loadConfigVars("setup", 'local'); ?>
<?php echo $_smarty_tpl->getSubTemplate ("base.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, null, array('title'=>'foo'), 0);?>


<?php echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, null, array(), 0);?>



<?php echo $_smarty_tpl->getSubTemplate ("left.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, null, array(), 0);?>


<?php echo $_smarty_tpl->getSubTemplate ("right.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, null, array(), 0);?>


<?php echo $_smarty_tpl->getSubTemplate ("carouselad.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, null, array(), 0);?>



<div class="topiclistcontainer">

     
        <div class="technology row">
            <h2>推荐文章</h2>
            <div class="technology_list">
                <h4>那些年愿意陪你一起吃苦的女孩（文/佚名）</h4>
                <div class="col-md-10 tech_para">
                    <p class="para">09年我毕业了，没房没车没存款，孑然一身，一个人来了乌鲁木齐。因为这里有个女友在等我。 09年9月，我拿到了第一个月的工资，1700块，有点儿可怜。女朋友一个月1000，更可怜。 三个月后，我勉强可以拿到3000块了，女友依然停留在1000块，但生活质量终于有了</p>
                </div>
                <div class="col-md-2 images_1_of_4 bg1 pull-right">
                  <a href="./dispuser.php"> <img src="./img/userface/image2.gif" class="bg"/></a>
                </div>
                <div class="clearfix"></div>
                <div class="read_more">
                    <a href="./disparticle.php" class="fa-btn btn-1 btn-1e">查看原文</a>
                </div>  
            </div>
            <div class="technology_list1">
                <h4>中国最美丽的风景线（西藏游一）</h4>
                <div class="col-md-10 tech_para">
                    <p class="para">晚上从西宁西站坐上火车，临上车前在候车室看到有很多背着超大背囊的旅行者，还有几个老外只背着简单的行囊，是有点去高原的样子了，心里不免有些激动。 火车行了一路，晚上没有怎么盖被子，胡乱把被子绕在身上，这是一直以来坐夜车的坏习惯，这个</p>
                </div>
                <div class="col-md-2 images_1_of_4 bg1">
                    <a href="./dispuser.php"><img src="./img/userface/image45.gif" class="bg"/></a>
                </div>
                <div class="clearfix"></div>
                <div class="read_more">
                    <a href="./disparticle.php"  class="fa-btn btn-1 btn-1e">查看原文</a>
                </div>  
            </div>

            <div class="technology_list">
                <h4>那些年愿意陪你一起吃苦的女孩（文/佚名）</h4>
                <div class="col-md-10 tech_para">
                    <p class="para">09年我毕业了，没房没车没存款，孑然一身，一个人来了乌鲁木齐。因为这里有个女友在等我。 09年9月，我拿到了第一个月的工资，1700块，有点儿可怜。女朋友一个月1000，更可怜。 三个月后，我勉强可以拿到3000块了，女友依然停留在1000块，但生活质量终于有了</p>
                </div>
                <div class="col-md-2 images_1_of_4 bg1 pull-right">
                    <a href="dispuser.php"><img src="./img/userface/image25.gif" class="bg" /></a>
                </div>
                <div class="clearfix"></div>
                <div class="read_more">
                    <a href="./disparticle.php"  class="fa-btn btn-1 btn-1e">查看原文</a>
                </div>  
            </div>
            <div class="technology_list1">
                <h4>中国最美丽的风景线（西藏游一）</h4>
                <div class="col-md-10 tech_para">
                    <p class="para">晚上从西宁西站坐上火车，临上车前在候车室看到有很多背着超大背囊的旅行者，还有几个老外只背着简单的行囊，是有点去高原的样子了，心里不免有些激动。 火车行了一路，晚上没有怎么盖被子，胡乱把被子绕在身上，这是一直以来坐夜车的坏习惯，这个</p>
                </div>
                <div class="col-md-2 images_1_of_4 bg1">
                    <a href="./dispuser.php"><img src="./img/userface/image43.gif" class="bg"/></a>
                </div>
                <div class="clearfix"></div>
                <div class="read_more">
                    <a href="./disparticle.php"  class="fa-btn btn-1 btn-1e">查看原文</a>
                </div>  
            </div>
           
        </div>
  
</div>

    <?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, null, array(), 0);?>
<?php }} ?>
