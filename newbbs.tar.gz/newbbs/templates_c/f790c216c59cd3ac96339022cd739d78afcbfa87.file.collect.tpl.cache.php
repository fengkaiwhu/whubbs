<?php /* Smarty version Smarty-3.1.18, created on 2014-12-25 14:51:13
         compiled from ".\templates\collect.tpl" */ ?>
<?php /*%%SmartyHeaderCode:13394549969c8975b46-58625476%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f790c216c59cd3ac96339022cd739d78afcbfa87' => 
    array (
      0 => '.\\templates\\collect.tpl',
      1 => 1419425756,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '13394549969c8975b46-58625476',
  'function' => 
  array (
  ),
  'cache_lifetime' => 120,
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_549969c8a31379_92668651',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_549969c8a31379_92668651')) {function content_549969c8a31379_92668651($_smarty_tpl) {?><?php  $_config = new Smarty_Internal_Config("test.conf", $_smarty_tpl->smarty, $_smarty_tpl);$_config->loadConfigVars("setup", 'local'); ?>
<?php echo $_smarty_tpl->getSubTemplate ("base.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, null, array('title'=>'foo'), 0);?>


<?php echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, null, array(), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("left.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, null, array(), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("right.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, null, array(), 0);?>



<div class="mcontainer">
  <div>
        <div class="PCD_header">
            <div class="pf_wrap">
                <div class="cover_wrap banner_transition"style="background-image: url(/img/ad/as2.jpg);" >
                </div>
                <div class="shadow  S_shadow" layout-shell="false">
                    <div class="pf_photo " node-type="photo">
                        <p class="photo_wrap">
                            <a href="#" title="更换头像">
                                <img src="./img/userface/image43.gif" alt="srender晨旭" class="photo">
                            </a>
                        </p>
                    </div>

                    <div class="pf_username">
                        <span class="username">srender晨旭</span>
                        <span class="icon_bed"><a><i class="W_icon icon_pf_male"></i></a></span>
                    </div>
                    <div class="pf_intro" title="给我感觉！">
                        给我感觉！                   
                    </div>
    	       </div>
            </div>
        </div>
    
        <div id="Pl_Core_CustTab__2" name="place" anchor="-50">
            <div class="PCD_tab S_bg2">
            <div class="tab_wrap" style="width: 60%">
                   <div class="WB_tab_b S_bg2">
                    <div class="opt_choose">

                        <div class="inner S_line2 clearfix">
                          
                            <div class="W_fr">
								<div class="row">
								 <div class="col-lg-6">
									<ul class="tab_ul W_fl">
	                                <!--当前态-->
	                                <li class="tab_li"><a href="/fav?type=mine&amp;wvr=6" class="tab_item tab_cur">
	                                    <span class="W_f14 S_txt1">我的收藏</span>
	                                    <em class="attach S_txt1">（共1043条）</em>
	                                    <span class="ani_border"></span>
	                                </a>

	                                </li>
	                                <!--/当前态-->
	                               
	                                </li>
	                            	</ul>
								</div>	
								  <div class="col-lg-6">
								    <div class="input-group">
								      <span class="input-group-btn">
								        <button class="btn btn-default" type="button">Go!</button>
								      </span>
								      <input type="text" class="form-control" placeholder="搜索自己收藏内容">
								    </div><!-- /input-group -->
								  </div><!-- /.col-lg-6 -->
								</div>


                            </div>
                        </div>
                    </div>
                </div>
            </div>
		 </div>
        </div>
    </div>
    <div class="WB_main_c">
        <div id="v6_pl_content_favlistsearch">
            <div class="WB_cardwrap feed_pop_tag S_bg2">
           
            </div>
        </div>
        
        <div id="v6_pl_content_myfavoriteslist">
            <div>
                <div class="WB_feed">
					<!--1-->
	                <div class="WB_cardwrap WB_feed_type S_bg2">
	                    <div class="WB_feed_detail clearfix">
	                       
	                        <div class="WB_face W_fl">
	                            <div class="face">
	                                <a target="_blank" class="W_face_radius" href="" title="Eexpert">
	                                    <img title="srender 晨旭" alt="" width="50" height="50" src="./img/userface/image123.gif" class="W_face_radius"></a>
	                            </div>
	                        </div>
	                        <div class="WB_detail">
	                            <div class="WB_info">
	                                <a target="_blank" class="W_f14 W_fb S_txt1" title="Eexpert" href="./dispuser.php">Eexpert</a>
	                                <a  target="_blank" href="">
                                      <span class="W_icon_level icon_level_c3">
                                            <span class="txt_out">
                                            <span class="txt_in">
                                                  <span title="山水等级">
                                                  版主
                                                  </span>
                                            </span>
                                            </span>
                                       </span>
                                    </a>
	                            </div>

	                            <div class="WB_text W_f14">
								<a href="./disparticle.php">
	                             年终了，大家评评哪个武大哪个食堂最差？哪个食堂最好？
								</a>		
	                             </div>

	                            <div class="WB_tag clearfix S_txt2">
	                                <span class="W_fr">收藏于12月6日11:41</span>
	                       
	                            </div>
	                            <!-- /feed区组件_收藏tag -->
	                            <div class="WB_from S_txt2">
	                                <a target="_blank" href="#" title="2014-12-06 10:30" class="S_txt2">12月6日 10:30</a>  来自
				                 	<a class="S_txt2" target="_blank" href="./board.php" rel="nofollow">版面名称</a>
	                            </div>

	                        </div>
	                    </div>
	                    <div class="WB_feed_handle">
	                        <div class="WB_handle">
	                            <ul class="WB_row_line WB_row_r4 clearfix S_line2">
	                                 <li>
                                        <a class="S_txt2" href="javascript:void(0);"><span class="pos"><span class="line S_line1">取消收藏</span></span></a>
                                    </li>
                                     <li>
                                        <a class="S_txt2" href="javascript:void(0);"><span class="pos"><span class="line S_line1">回复</span></span></a>
                                    </li>
	                            </ul>
	                        </div>
	                        <div class="WB_feed_repeat S_bg1" style="display: none;"></div>
	                    </div>
	                </div>
					<!--1 end-->

					<!--2-->
					<div class="WB_cardwrap WB_feed_type S_bg2">
	                    <div class="WB_feed_detail clearfix">
	                       
	                        <div class="WB_face W_fl">
	                            <div class="face">
	                                <a target="_blank" class="W_face_radius" href="" title="Taylor swift">
	                                    <img title="srender 晨旭" alt="" width="50" height="50" src="./img/userface/image78.gif" class="W_face_radius"></a>
	                            </div>
	                        </div>
	                        <div class="WB_detail">
	                            <div class="WB_info">
	                                <a target="_blank" class="W_f14 W_fb S_txt1" title="srender 晨旭" href="./dispuser.php">Taylor swift</a>
	                                <a  target="_blank" href="">
                                      <span class="W_icon_level icon_level_c3">
                                            <span class="txt_out">
                                            <span class="txt_in">
                                                  <span title="山水等级">版主</span>
                                            </span>
                                            </span>
                                       </span>
                                    </a>
	                            </div>

	                            <div class="WB_text W_f14">
	                            <a href="./disparticle.php">
	                            	泰勒·斯威夫特（Taylor Swift），1989年12月13日出生于美国宾夕法尼亚州，美国乡村音乐、流行音乐创作女歌手、演员、慈善家。
	                            </a>	
	                            </div>

	                            <div class="WB_tag clearfix S_txt2">
	                                <span class="W_fr">收藏于12月6日11:41</span>
	                            
	                            </div>
	          
	                            <div class="WB_from S_txt2">
	                                <a target="_blank" href="" title="2014-12-06 10:30" class="S_txt2">12月6日 10:30</a>  来自
				                 	<a class="S_txt2" target="_blank" href="./board.php" rel="nofollow">版面名称</a>
	                            </div>

	                        </div>
	                    </div>
	                    <div class="WB_feed_handle">
	                        <div class="WB_handle">
	                            <ul class="WB_row_line WB_row_r4 clearfix S_line2">
	                                  <li>
                                        <a class="S_txt2" href="javascript:void(0);"><span class="pos"><span class="line S_line1">取消收藏</span></span></a>
                                    </li>
                                     <li>
                                        <a class="S_txt2" href="javascript:void(0);"><span class="pos"><span class="line S_line1">回复</span></span></a>
                                    </li>
	                            </ul>
	                        </div>
	                        <div class="WB_feed_repeat S_bg1" style="display: none;"></div>
	                    </div>
	                </div>
					<!--2 end-->

					<!--3-->	
					<div class="WB_cardwrap WB_feed_type S_bg2">
	                    <div class="WB_feed_detail clearfix">
	                        <div class="WB_screen W_fr">
	                            <div class="screen_box">
	                               
	                            </div>
	                        </div>
	                        <div class="WB_face W_fl">
	                            <div class="face">
	                                <a target="_blank" class="W_face_radius" href="" title="srender 晨旭">
	                                    <img title="srender 晨旭" alt="" width="50" height="50" src="./img/userface/image23.gif" class="W_face_radius"></a>
	                            </div>
	                        </div>
	                        <div class="WB_detail">
	                            <div class="WB_info">
	                                <a target="_blank" class="W_f14 W_fb S_txt1" title="srender 晨旭" href="./dispuser.php">srender 晨旭</a>
	                                <a  target="_blank" href="">
                                      <span class="W_icon_level icon_level_c3">
                                            <span class="txt_out">
                                            <span class="txt_in">
                                                  <span title="山水等级">用户</span>
                                            </span>
                                            </span>
                                       </span>
                                    </a>
	                            </div>

	                            <div class="WB_text W_f14">
	                            <a href="./disparticle.php">
	                            《想做web开发，就学JavaScript》为了快速地在web开发工作上增加优势，应该学习什么语言？
	                            </a>
	                            </div>

	                            <div class="WB_tag clearfix S_txt2">
	                                <span class="W_fr">收藏于12月6日11:41</span>
	                            </div>
	                            <!-- /feed区组件_收藏tag -->
	                            <div class="WB_from S_txt2">
	                                <a target="_blank" href="" title="2014-12-06 10:30" class="S_txt2">12月6日 10:30</a>  来自
				                 	<a class="S_txt2" target="_blank" href="./board.php" rel="nofollow">版面名称</a>
	                            </div>

	                        </div>
	                    </div>
	                    <div class="WB_feed_handle">
	                        <div class="WB_handle">
	                            <ul class="WB_row_line WB_row_r4 clearfix S_line2">
	                                <li>
	                                    <a class="S_txt2" href="javascript:void(0);"><span class="pos"><span class="line S_line1">取消收藏</span></span></a>
	                                </li>
	                                 <li>
                                        <a class="S_txt2" href="javascript:void(0);"><span class="pos"><span class="line S_line1">回复</span></span></a>
                                    </li>
	                            </ul>
	                        </div>
	                        <div class="WB_feed_repeat S_bg1" style="display: none;"></div>
	                    </div>
	                </div>
					<!--3 end-->


					<!--4-->
					<div class="WB_cardwrap WB_feed_type S_bg2">
	                    <div class="WB_feed_detail clearfix">
	                        <div class="WB_screen W_fr">
	                            <div class="screen_box">
	                                <a href="javascript:void(0);"><i class="W_ficon ficon_arrow_down S_ficon">c</i></a>
	                                <div class="layer_menu_list" style="display: none; position: absolute; z-index: 999;">
	                                  
	                                </div>
	                            </div>
	                        </div>
	                        <div class="WB_face W_fl">
	                            <div class="face">
	                                <a target="_blank" class="W_face_radius" href="" title="技术宅的出路">
	                                    <img title="srender 晨旭" alt="" width="50" height="50" src="./img/userface/image66.gif" class="W_face_radius"></a>
	                            </div>
	                        </div>
	                        <div class="WB_detail">
	                            <div class="WB_info">
	                                <a target="_blank" class="W_f14 W_fb S_txt1" title="技术宅的出路" href="./dispuser.php">技术宅的出路</a>
	                                <a  target="_blank" href="">
                                      <span class="W_icon_level icon_level_c3">
                                            <span class="txt_out">
                                            <span class="txt_in">
                                                  <span title="山水等级">超级用户</span>
                                            </span>
                                            </span>
                                       </span>
                                    </a>
	                            </div>

	                            <div class="WB_text W_f14">
	                            <a href="./disparticle.php">
	                            	周杰伦（Jay Chou），1979年1月18日出生于台湾新北市，华语男歌手、词曲创作人、演员、MV及电影导演、编剧及制作人。2000年发行首张个人专辑《Jay》。2002年在中国、新加坡、马来西亚、美国等地举办首场个人世界巡回演唱会。2003年登上美国《时代周刊》亚洲版封面人物[1] 。
	                            </a>	
	                            </div>
	                            <div class="WB_tag clearfix S_txt2">
	                                <span class="W_fr">收藏于12月6日11:41</span>
	                         
	                            </div>
	                            <!-- /feed区组件_收藏tag -->
	                            <div class="WB_from S_txt2">
	                                <a target="_blank" href="" title="2014-12-06 10:30" class="S_txt2">12月6日 10:30</a>  来自
				                 	<a class="S_txt2" target="_blank" href="./board.php" rel="nofollow">版面名称</a>
	                            </div>

	                        </div>
	                    </div>
	                    <div class="WB_feed_handle">
	                        <div class="WB_handle">
	                            <ul class="WB_row_line WB_row_r4 clearfix S_line2">
	                                <li>
	                                    <a class="S_txt2" href="javascript:void(0);"><span class="pos"><span class="line S_line1">取消收藏</span></span></a>
	                                </li>
	                                <li>
	                                    <a class="S_txt2" href="javascript:void(0);">
	                                        <span class="pos">
	                                            <span class="line S_line1">转发 8
	                                            </span>
	                                        </span>
	                                    </a>
	                                </li>
                                </ul>
	                        </div>
	                        <div class="WB_feed_repeat S_bg1" style="display: none;"></div>
	                    </div>
	                </div>					
					<!--4 end-->
				</div>
            </div>
        </div>

		<nav class="collectbottomnav">
		  <ul class="pagination">
		    <li><a href="#">&laquo;</a></li>
		    <li><a href="#">1</a></li>
		    <li><a href="#">2</a></li>
		    <li><a href="#">3</a></li>
		    <li><a href="#">4</a></li>
		    <li><a href="#">5</a></li>
		    <li><a href="#">6</a></li>
		    <li><a href="#">&raquo;</a></li>
		  </ul>
		</nav>
    </div>   
<!--end mcontainer-->
</div>

<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, null, array(), 0);?>

<?php }} ?>
