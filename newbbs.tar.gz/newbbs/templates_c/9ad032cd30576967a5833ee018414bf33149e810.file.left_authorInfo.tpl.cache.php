<?php /* Smarty version Smarty-3.1.18, created on 2014-12-21 11:04:01
         compiled from ".\templates\left_authorInfo.tpl" */ ?>
<?php /*%%SmartyHeaderCode:9513548d51dec05f09-60548136%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9ad032cd30576967a5833ee018414bf33149e810' => 
    array (
      0 => '.\\templates\\left_authorInfo.tpl',
      1 => 1419156239,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '9513548d51dec05f09-60548136',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_548d51dec21488_33828953',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_548d51dec21488_33828953')) {function content_548d51dec21488_33828953($_smarty_tpl) {?>  <div id="articleArea">

            <div id="authorArea">
             <div id="authorName">
                    <a target="_blank" href="javascript:void(0);" title="kiki1010" >
                        <h3>kiki1010</h3>
                    </a>
                </div>

              <div class="fm-header-bar" style="float: right;margin-top:20px;">
                <div class="fm-main">
                    <div class="row-fluid">
                        
                            <dt class="w2 pr" style="overflow:visible" >
                              
                                <a href="" class='fm_popovercard' data-obj_id='1' data-url='get_card.php?id='>
                    
                                <img src="img/two.jpg" alt="kiki1010" class="authorImg" >
                                </a>
                          
                            </dt>
                        
                    </div>
                </div>
            </div>
        
            
                <!--作者信息-->
              
               
                <br />
                <!--签名档-->
                <div id="authorInfo">
                    <p>
                        有些事，明知是错的，也要去坚持，因为不甘心；有些人，明知是爱的，也要去放弃，因为没结
            局；有时候，明知没路了，却还在前行，因为习惯了。
                    </p>
                </div>
            </div>

           <?php }} ?>
