<?php /* Smarty version Smarty-3.1.18, created on 2014-12-29 04:52:04
         compiled from ".\templates\usermanagemenu.tpl" */ ?>
<?php /*%%SmartyHeaderCode:30250549683fdd8bc50-95897455%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '58abbab8bdd8e11a44ef893dc7bd4f6c890139b8' => 
    array (
      0 => '.\\templates\\usermanagemenu.tpl',
      1 => 1419825049,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '30250549683fdd8bc50-95897455',
  'function' => 
  array (
  ),
  'cache_lifetime' => 120,
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_549683fde04df5_78675478',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_549683fde04df5_78675478')) {function content_549683fde04df5_78675478($_smarty_tpl) {?><?php  $_config = new Smarty_Internal_Config("test.conf", $_smarty_tpl->smarty, $_smarty_tpl);$_config->loadConfigVars("setup", 'local'); ?>

<?php echo $_smarty_tpl->getSubTemplate ("base.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, null, array('title'=>'hello'), 0);?>


<?php echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, null, array(), 0);?>


<?php echo $_smarty_tpl->getSubTemplate ("left.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, null, array(), 0);?>


<?php echo $_smarty_tpl->getSubTemplate ("right.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, null, array(), 0);?>



<?php echo $_smarty_tpl->getSubTemplate ("carouselad.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, null, array(), 0);?>

<script type="text/javascript" src="js/smartpaginator.js"></script>
<link href="css/smartpaginator.css" rel="stylesheet" type="text/css" />
<div class="votecontainer containerradius">





<div class="col-xs-4">
                <table class="table">
                    <tbody>
                        <tr align="center">
                           <div class="WB_main_r">
                                
                                <div id="v6_pl_rightmod_myinfo">
                                    <div class="WB_cardwrap S_bg2">
                                        <div class="W_person_info">
                                            <div class="cover" id="skin_cover_s" style="background-image: url(./img/1.jpg)">
                                                <div class="headpic"><a title="srender晨旭">
                                                    <img class="W_face_radius" src="./img/userface/image6.gif" width="60" height="60" alt="srender晨旭">
                                                    </a>
                                                   </div>
                                            </div>
                                            <div class="WB_innerwrap">
                                                <div class="nameBox">
                                                <a href=" " class="name S_txt1" title="srender晨旭">
                                                     E时代专家
                                                </a>
                                                <a  target="_blank" href="">
                                                <span class="W_icon_level icon_level_c3">
                                                    <span class="txt_out">
                                                    <span class="txt_in">
                                                        <span title="山水等级">用户</span>
                                                    </span>
                                                    </span>
                                                </span>
                                                </a>
                                                </div>
                                                <ul class="user_atten clearfix W_f18" id="person-info">
                                                    <li class="S_line1" id="login-time">
                                                        <a class="S_txt1" >
                                                        <strong>204</strong>
                                                        <span class="S_txt2">登录</span>
                                                        </a>
                                                    </li>
                                                    <li class="S_line1" id="friend-number">
                                                    <a class="S_txt1">
                                                        <strong>358</strong>
                                                        <span class="S_txt2">好友</span>
                                                        </a>
                                                    </li>
                                                    <li class="S_line1 noborder" id="tiezi-number">
                                                    <a class="S_txt1">
                                                        <strong>143</strong>
                                                        <span class="S_txt2">帖子</span>
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                        </tr>
                        <tr>
                            <th class="userth">基本信息</th>
                        </tr>
                        <tr>
                            <td align="left" valign="top">用户昵称： E时代专家<br>
                                用户等级： 用户<br>
                                用户门派： 3.14<br>
                                帖数总数： 7<br>
                                注册时间： 2014-11-24 <br>
                                登录次数： 43<br>
                            </td>
                        </tr>
                    </tbody>
                </table>
 </div>         
          
<div class="col-xs-8 personpulish">
                <table class="table">
                <caption class="userth">个人帖子</caption>
                    <tbody>
                       
                        <tr>
                            <td align="left">
                              如何在互联网时代生存
                                 <span class="W_icon_level icon_level_c3">
                                            <span class="txt_out">
                                            <span class="txt_in">
                                                  <span title="山水等级">
                                                  22
                                                  </span>
                                            </span>
                                            </span>
                                       </span>
                            </td>
                            <td>2012.30.8</td>
                            
                        </tr>

                      
                         </tr>

                           <tr>
                            <td align="left">
                              西宁我的梦455
                                 <span class="W_icon_level icon_level_c3">
                                            <span class="txt_out">
                                            <span class="txt_in">
                                                  <span title="山水等级">
                                                  22
                                                  </span>
                                            </span>
                                            </span>
                                       </span>
                            </td>
                            <td>2012.30.8</td>
                            
                        </tr>
                         </tr>

                           <tr>
                            <td align="left">
                              西宁我的梦11
                                 <span class="W_icon_level icon_level_c3">
                                            <span class="txt_out">
                                            <span class="txt_in">
                                                  <span title="山水等级">
                                                  22
                                                  </span>
                                            </span>
                                            </span>
                                       </span>
                            </td>
                            <td>2012.30.8</td>
                            
                        </tr>
                         </tr>

                           <tr>
                            <td align="left">
                              西宁我的梦22
                                 <span class="W_icon_level icon_level_c3">
                                            <span class="txt_out">
                                            <span class="txt_in">
                                                  <span title="山水等级">
                                                  22
                                                  </span>
                                            </span>
                                            </span>
                                       </span>
                            </td>
                            <td>2012.30.8</td>
                            
                        </tr>
                         </tr>

                           <tr>
                            <td align="left">
                              西宁我的梦23
                                 <span class="W_icon_level icon_level_c3">
                                            <span class="txt_out">
                                            <span class="txt_in">
                                                  <span title="山水等级">
                                                  22
                                                  </span>
                                            </span>
                                            </span>
                                       </span>
                            </td>
                            <td>2012.30.8</td>
                            
                        </tr>

                            <tr>
                            <td align="left">
                              西宁我的梦23
                                 <span class="W_icon_level icon_level_c3">
                                            <span class="txt_out">
                                            <span class="txt_in">
                                                  <span title="山水等级">
                                                  22
                                                  </span>
                                            </span>
                                            </span>
                                       </span>
                            </td>
                            <td>2012.30.8</td>
                            
                        </tr>

                            <tr>
                            <td align="left">
                              西宁我的梦23
                                 <span class="W_icon_level icon_level_c3">
                                            <span class="txt_out">
                                            <span class="txt_in">
                                                  <span title="山水等级">
                                                  22
                                                  </span>
                                            </span>
                                            </span>
                                       </span>
                            </td>
                            <td>2012.30.8</td>
                            
                        </tr>

                            <tr>
                            <td align="left">
                              西宁我的梦23
                                 <span class="W_icon_level icon_level_c3">
                                            <span class="txt_out">
                                            <span class="txt_in">
                                                  <span title="山水等级">
                                                  22
                                                  </span>
                                            </span>
                                            </span>
                                       </span>
                            </td>
                            <td>2012.30.8</td>
                            
                        </tr>

                            <tr>
                            <td align="left">
                              西宁我的梦23
                                 <span class="W_icon_level icon_level_c3">
                                            <span class="txt_out">
                                            <span class="txt_in">
                                                  <span title="山水等级">
                                                  22
                                                  </span>
                                            </span>
                                            </span>
                                       </span>
                            </td>
                            <td>2012.30.8</td>
                            
                        </tr>
                    </tbody>
                </table>
    
</div>

<!--My collection-->

<div class="col-xs-12 collectarea">
<table class="table">
        <caption class="collectth">我的收藏</caption> 
      <tbody>
        <div id="v6_pl_content_myfavoriteslist">
            <div>
                <div class="WB_feed">
                    <!--1-->
                     <tr>
                     <td>
                         <div class="WB_cardwrap WB_feed_type S_bg2">
                        <div class="WB_feed_detail clearfix">
                           
                            <div class="WB_face W_fl">
                                <div class="face">
                                    <a target="_blank" class="W_face_radius" href="" title="Eexpert">
                                        <img title="srender 晨旭" alt="" width="50" height="50" src="./img/userface/image123.gif" class="W_face_radius"></a>
                                </div>
                            </div>
                            <div class="WB_detail">
                                <div class="WB_info">
                                    <a target="_blank" class="W_f14 W_fb S_txt1" title="Eexpert" href="./dispuser.php">Eexpert</a>
                                    <a  target="_blank" href="">
                                      <span class="W_icon_level icon_level_c3">
                                            <span class="txt_out">
                                            <span class="txt_in">
                                                  <span title="山水等级">
                                                  版主
                                                  </span>
                                            </span>
                                            </span>
                                       </span>
                                    </a>
                                </div>

                                <div class="WB_text W_f14">
                                <a href="./disparticle.php">
                                 年终了，大家评评哪个武大哪个食堂最差？哪个食堂最好？
                                </a>        
                                 </div>

                                <div class="WB_tag clearfix S_txt2">
                                    <span class="W_fr">收藏于12月6日11:41</span>
                           
                                </div>
                                <!-- /feed区组件_收藏tag -->
                                <div class="WB_from S_txt2">
                                    <a target="_blank" href="#" title="2014-12-06 10:30" class="S_txt2">12月6日 10:30</a>  来自
                                    <a class="S_txt2" target="_blank" href="./board.php" rel="nofollow">版面名称</a>
                                </div>

                            </div>
                        </div>
                        <div class="WB_feed_handle">
                            <div class="WB_handle">
                                <ul class="WB_row_line WB_row_r4 clearfix S_line2">
                                     <li>
                                        <a class="S_txt2" href="javascript:void(0);"><span class="pos"><span class="line S_line1">取消收藏</span></span></a>
                                    </li>
                                     <li>
                                        <a class="S_txt2" href="javascript:void(0);"><span class="pos"><span class="line S_line1">回复</span></span></a>
                                    </li>
                                </ul>
                            </div>
                            <div class="WB_feed_repeat S_bg1" style="display: none;"></div>
                        </div>
                    </div>
                    </td>
                    </tr>
                    <!--1 end-->

                    <!--2-->
                    <tr>
                     <td>
                          <div class="WB_cardwrap WB_feed_type S_bg2">
                        <div class="WB_feed_detail clearfix">
                           
                            <div class="WB_face W_fl">
                                <div class="face">
                                    <a target="_blank" class="W_face_radius" href="" title="Taylor swift">
                                        <img title="srender 晨旭" alt="" width="50" height="50" src="./img/userface/image78.gif" class="W_face_radius"></a>
                                </div>
                            </div>
                            <div class="WB_detail">
                                <div class="WB_info">
                                    <a target="_blank" class="W_f14 W_fb S_txt1" title="srender 晨旭" href="./dispuser.php">Taylor swift</a>
                                    <a  target="_blank" href="">
                                      <span class="W_icon_level icon_level_c3">
                                            <span class="txt_out">
                                            <span class="txt_in">
                                                  <span title="山水等级">版主</span>
                                            </span>
                                            </span>
                                       </span>
                                    </a>
                                </div>

                                <div class="WB_text W_f14">
                                <a href="./disparticle.php">
                                    泰勒·斯威夫特（Taylor Swift），1989年12月13日出生于美国宾夕法尼亚州，美国乡村音乐、流行音乐创作女歌手、演员、慈善家。
                                </a>    
                                </div>

                                <div class="WB_tag clearfix S_txt2">
                                    <span class="W_fr">收藏于12月6日11:41</span>
                                
                                </div>
              
                                <div class="WB_from S_txt2">
                                    <a target="_blank" href="" title="2014-12-06 10:30" class="S_txt2">12月6日 10:30</a>  来自
                                    <a class="S_txt2" target="_blank" href="./board.php" rel="nofollow">版面名称</a>
                                </div>

                            </div>
                        </div>
                        <div class="WB_feed_handle">
                            <div class="WB_handle">
                                <ul class="WB_row_line WB_row_r4 clearfix S_line2">
                                      <li>
                                        <a class="S_txt2" href="javascript:void(0);"><span class="pos"><span class="line S_line1">取消收藏</span></span></a>
                                    </li>
                                     <li>
                                        <a class="S_txt2" href="javascript:void(0);"><span class="pos"><span class="line S_line1">回复</span></span></a>
                                    </li>
                                </ul>
                            </div>
                            <div class="WB_feed_repeat S_bg1" style="display: none;"></div>
                        </div>
                    </div>
                    </td>
                    </tr>
                    <!--2 end-->

                    <!--3-->
                    <tr>
                     <td>    
                          <div class="WB_cardwrap WB_feed_type S_bg2">
                        <div class="WB_feed_detail clearfix">
                            <div class="WB_screen W_fr">
                                <div class="screen_box">
                                   
                                </div>
                            </div>
                            <div class="WB_face W_fl">
                                <div class="face">
                                    <a target="_blank" class="W_face_radius" href="" title="srender 晨旭">
                                        <img title="srender 晨旭" alt="" width="50" height="50" src="./img/userface/image23.gif" class="W_face_radius"></a>
                                </div>
                            </div>
                            <div class="WB_detail">
                                <div class="WB_info">
                                    <a target="_blank" class="W_f14 W_fb S_txt1" title="srender 晨旭" href="./dispuser.php">srender 晨旭</a>
                                    <a  target="_blank" href="">
                                      <span class="W_icon_level icon_level_c3">
                                            <span class="txt_out">
                                            <span class="txt_in">
                                                  <span title="山水等级">用户</span>
                                            </span>
                                            </span>
                                       </span>
                                    </a>
                                </div>

                                <div class="WB_text W_f14">
                                <a href="./disparticle.php">
                                《想做web开发，就学JavaScript》为了快速地在web开发工作上增加优势，应该学习什么语言？
                                </a>
                                </div>

                                <div class="WB_tag clearfix S_txt2">
                                    <span class="W_fr">收藏于12月6日11:41</span>
                                </div>
                                <!-- /feed区组件_收藏tag -->
                                <div class="WB_from S_txt2">
                                    <a target="_blank" href="" title="2014-12-06 10:30" class="S_txt2">12月6日 10:30</a>  来自
                                    <a class="S_txt2" target="_blank" href="./board.php" rel="nofollow">版面名称</a>
                                </div>

                            </div>
                        </div>
                        <div class="WB_feed_handle">
                            <div class="WB_handle">
                                <ul class="WB_row_line WB_row_r4 clearfix S_line2">
                                    <li>
                                        <a class="S_txt2" href="javascript:void(0);"><span class="pos"><span class="line S_line1">取消收藏</span></span></a>
                                    </li>
                                     <li>
                                        <a class="S_txt2" href="javascript:void(0);"><span class="pos"><span class="line S_line1">回复</span></span></a>
                                    </li>
                                </ul>
                            </div>
                            <div class="WB_feed_repeat S_bg1" style="display: none;"></div>
                        </div>
                    </div>
                    </td>
                    </tr>
                    <!--3 end-->


                    <!--4-->
                    <tr>
                     <td>
                      <div class="WB_cardwrap WB_feed_type S_bg2">
                        <div class="WB_feed_detail clearfix">
                            <div class="WB_screen W_fr">
                                <div class="screen_box">
                                    <a href="javascript:void(0);"><i class="W_ficon ficon_arrow_down S_ficon">c</i></a>
                                    <div class="layer_menu_list" style="display: none; position: absolute; z-index: 999;">
                                      
                                    </div>
                                </div>
                            </div>
                            <div class="WB_face W_fl">
                                <div class="face">
                                    <a target="_blank" class="W_face_radius" href="" title="技术宅的出路">
                                        <img title="srender 晨旭" alt="" width="50" height="50" src="./img/userface/image66.gif" class="W_face_radius"></a>
                                </div>
                            </div>
                            <div class="WB_detail">
                                <div class="WB_info">
                                    <a target="_blank" class="W_f14 W_fb S_txt1" title="技术宅的出路" href="./dispuser.php">技术宅的出路</a>
                                    <a  target="_blank" href="">
                                      <span class="W_icon_level icon_level_c3">
                                            <span class="txt_out">
                                            <span class="txt_in">
                                                  <span title="山水等级">超级用户</span>
                                            </span>
                                            </span>
                                       </span>
                                    </a>
                                </div>

                                <div class="WB_text W_f14">
                                <a href="./disparticle.php">
                                    周杰伦（Jay Chou），1979年1月18日出生于台湾新北市，华语男歌手、词曲创作人、演员、MV及电影导演、编剧及制作人。2000年发行首张个人专辑《Jay》。2002年在中国、新加坡、马来西亚、美国等地举办首场个人世界巡回演唱会。2003年登上美国《时代周刊》亚洲版封面人物[1] 。
                                </a>    
                                </div>
                                <div class="WB_tag clearfix S_txt2">
                                    <span class="W_fr">收藏于12月6日11:41</span>
                             
                                </div>
                                <!-- /feed区组件_收藏tag -->
                                <div class="WB_from S_txt2">
                                    <a target="_blank" href="" title="2014-12-06 10:30" class="S_txt2">12月6日 10:30</a>  来自
                                    <a class="S_txt2" target="_blank" href="./board.php" rel="nofollow">版面名称</a>
                                </div>

                            </div>
                        </div>
                        <div class="WB_feed_handle">
                            <div class="WB_handle">
                                <ul class="WB_row_line WB_row_r4 clearfix S_line2">
                                    <li>
                                        <a class="S_txt2" href="javascript:void(0);"><span class="pos"><span class="line S_line1">取消收藏</span></span></a>
                                    </li>
                                    <li>
                                        <a class="S_txt2" href="javascript:void(0);">
                                            <span class="pos">
                                                <span class="line S_line1">转发 8
                                                </span>
                                            </span>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                            <div class="WB_feed_repeat S_bg1" style="display: none;"></div>
                        </div>
                     </div>   
                     </td>
                     </tr>               
                    <!--4 end-->
                </div>
            </div>
        </div>

      
    </div> 
</div>

<tr>
    <td>
        <div id="collectwrapper">
        
            <div id="skyblue" style="margin: auto;">
            </div>
        </div>
    </td>
</tr>

</tbody>
</table>
<!--My collection  End-->
  
<!--End contianer-->
</div>




</div>



  <script type="text/javascript">
        $(document).ready(function () {

          $('#skyblue').smartpaginator({ totalrecords: 32, recordsperpage: 4, length: 4, next: '下一页', prev: '前一页', first: '首页', last: '尾页', theme: 'skyblue', controlsalways: true, onchange: function (newPage) {
                $('#r').html('Page # ' + newPage);
            }
            });

        });
    </script>
<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, null, array(), 0);?>
<?php }} ?>
