<?php /* Smarty version Smarty-3.1.18, created on 2014-12-19 16:44:39
         compiled from ".\templates\topicLi.tpl" */ ?>
<?php /*%%SmartyHeaderCode:14849549447e74e1073-31000640%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '13e00d7fc7b763f8c864417db83b29545ac7256e' => 
    array (
      0 => '.\\templates\\topicLi.tpl',
      1 => 1419003851,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '14849549447e74e1073-31000640',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_549447e74e8d72_07562071',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_549447e74e8d72_07562071')) {function content_549447e74e8d72_07562071($_smarty_tpl) {?>    <div class="container">
        <div id="cc-content">
            <ul class="cc-list">
                <li>
                    <div class="classItem">
                        <h2 class="name">
                            <a href="/testsmarty/topicView.php">
                            大一新生
                            </a>
                        </h2>

                        <span class="badge">5</span>

                        <div class="leader">
                            <span>版主：</span> 
                            <a target="_blank" href="javascript:void(0);" class="leader_img" title="么么哒" >
                                <img src="img/one.jpg" >
                            </a>
                        </div>
                        <div class="seq"></div>
                    </div>
                </li>

                <li>
                    <div class="classItem">

                        <h2 class="name">
                            <a href="/testsmarty/topicView.php">
                            毕业生
                            </a>
                        </h2>

                        <span class="badge">14</span>

                        <div class="leader">
                            <span>版主：</span> 
                            <a target="_blank" href="javascript:void(0);" class="leader_img" title="呵呵哒" >
                                <img src="img/two.jpg" >
                            </a>
                        </div>
                        <div class="seq"></div>
                    </div>
                </li>

                <li>
                    <div class="classItem">

                        <h2 class="name">
                            <a href="/testsmarty/topicView.php">
                            珞珈金秋
                            </a>
                        </h2>

                        <span class="badge">14</span>

                        <div class="leader">
                            <span>版主：</span> 
                            <a target="_blank" href="javascript:void(0);" class="leader_img" title="2哒" >
                                <img src="img/three.jpg" >
                            </a>
                        </div>
                        <div class="seq"></div>
                    </div>

                </li>

                <li>
                    <div class="classItem">

                        <h2 class="name">
                            <a href="javascript:void(0);">
                            毕业生
                            </a>
                        </h2>

                        <span class="badge">14</span>

                        <div class="leader">
                            <span>版主：</span> 
                            <a target="_blank" href="javascript:void(0);" class="leader_img" title="呵呵哒" >
                                <img src="img/two.jpg" >
                            </a>
                        </div>
                        <div class="seq"></div>
                    </div>
                </li>

                <li>
                    <div class="classItem">

                        <h2 class="name">
                            <a href="javascript:void(0);">
                            珞珈金秋
                            </a>
                        </h2>

                        <span class="badge">14</span>

                        <div class="leader">
                            <span>版主：</span> 
                            <a target="_blank" href="javascript:void(0);" class="leader_img" title="2哒" >
                                <img src="img/three.jpg" >
                            </a>
                        </div>
                        <div class="seq"></div>
                    </div>

                </li>

                <li>
                    <div class="classItem">

                        <h2 class="name">
                            <a href="javascript:void(0);">
                            毕业生
                            </a>
                        </h2>

                        <span class="badge">14</span>

                        <div class="leader">
                            <span>版主：</span> 
                            <a target="_blank" href="javascript:void(0);" class="leader_img" title="呵呵哒" >
                                <img src="img/two.jpg" >
                            </a>
                        </div>
                        <div class="seq"></div>
                    </div>
                </li>

                <li>
                    <div class="classItem">

                        <h2 class="name">
                            <a href="javascript:void(0);">
                            珞珈金秋
                            </a>
                        </h2>

                        <span class="badge">14</span>

                        <div class="leader">
                            <span>版主：</span> 
                            <a target="_blank" href="javascript:void(0);" class="leader_img" title="2哒" >
                                <img src="img/three.jpg" >
                            </a>
                        </div>
                        <div class="seq"></div>
                    </div>

                </li>

                <li>
                    <div class="classItem">

                        <h2 class="name">
                            <a href="javascript:void(0);">
                            毕业生
                            </a>
                        </h2>

                        <span class="badge">14</span>

                        <div class="leader">
                            <span>版主：</span> 
                            <a target="_blank" href="/testsmarty/topicView.php" class="leader_img" title="呵呵哒" >
                                <img src="img/two.jpg" >
                            </a>
                        </div>
                        <div class="seq"></div>
                    </div>
                </li>

                <li>
                    <div class="classItem">

                        <h2 class="name">
                            <a href="javascript:void(0);">
                            珞珈金秋
                            </a>
                        </h2>

                        <span class="badge">14</span>

                        <div class="leader">
                            <span>版主：</span> 
                            <a target="_blank" href="javascript:void(0);" class="leader_img" title="2哒" >
                                <img src="img/three.jpg" >
                            </a>
                        </div>
                        <div class="seq"></div>
                    </div>

                </li>

                <li>
                    <div class="classItem">

                        <h2 class="name">
                            <a href="javascript:void(0);">
                            毕业生
                            </a>
                        </h2>

                        <span class="badge">14</span>

                        <div class="leader">
                            <span>版主：</span> 
                            <a target="_blank" href="javascript:void(0);" class="leader_img" title="呵呵哒" >
                                <img src="img/two.jpg" >
                            </a>
                        </div>
                        <div class="seq"></div>
                    </div>
                </li>

                <li>
                    <div class="classItem">

                        <h2 class="name">
                            <a href="javascript:void(0);">
                            珞珈金秋
                            </a>
                        </h2>

                        <span class="badge">14</span>

                        <div class="leader">
                            <span>版主：</span> 
                            <a target="_blank" href="javascript:void(0);" class="leader_img" title="2哒" >
                                <img src="img/three.jpg" >
                            </a>
                        </div>
                        <div class="seq"></div>
                    </div>

                </li>

            </ul>
        </div>
    </div><?php }} ?>
