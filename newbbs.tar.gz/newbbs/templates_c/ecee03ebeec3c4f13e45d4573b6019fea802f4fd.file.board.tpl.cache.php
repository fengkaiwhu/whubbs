<?php /* Smarty version Smarty-3.1.18, created on 2014-12-29 04:38:36
         compiled from ".\templates\board.tpl" */ ?>
<?php /*%%SmartyHeaderCode:27434549583c5e94239-19913166%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ecee03ebeec3c4f13e45d4573b6019fea802f4fd' => 
    array (
      0 => '.\\templates\\board.tpl',
      1 => 1419783115,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '27434549583c5e94239-19913166',
  'function' => 
  array (
  ),
  'cache_lifetime' => 120,
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_549583c5f056c0_90470940',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_549583c5f056c0_90470940')) {function content_549583c5f056c0_90470940($_smarty_tpl) {?><?php  $_config = new Smarty_Internal_Config("test.conf", $_smarty_tpl->smarty, $_smarty_tpl);$_config->loadConfigVars("setup", 'local'); ?>
<?php echo $_smarty_tpl->getSubTemplate ("base.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, null, array('title'=>'foo'), 0);?>

<script type="text/javascript" src="js/smartpaginator.js"></script>
<link href="css/smartpaginator.css" rel="stylesheet" type="text/css" />

<?php echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, null, array(), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("left.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, null, array(), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("right.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, null, array(), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("carouselad.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, null, array(), 0);?>



<div class="usermailcontainer">
  <table class="table" align="center" >
        <tbody>
            <tr class="success">
                <th height="25" width="100%" align="left" id="TableTitleLink" style="font-weight: normal">本版当前共有<b>19</b>人在线。今日帖子0。
              
                
               [<a href="favboard.php?bname=Jiangxi" title="收藏本版面到收藏夹顶层目录"  >收藏本版</a>]
               &nbsp;[<a href="doclear.php?boardName=Jiangxi" title="将本版所有文章标记成已读">清除未读</a>]
                    <span id="onboard_users"></span></th>
            </tr>
        </tbody>
   </table>

    <!--******************************************************************-->
    <div class="topicListcontainer">
    <table class="table listtable">
        <tbody>
            <tr class="active">
                <td width="110px">
                    <a href="postarticle.php?board=Jiangxi">
                        <div class="buttonClass1"  title="发新帖">
                        </div>
                    </a>
                </td>
                <td align="right">
                    <img src="img/pic/team2.gif" align="absmiddle">
                    <a href="dispuser.php?id=wad87812" target="_blank" title="点击查看该版主资料">wad87812</a>
                </td>
            </tr>

        </tbody>
    </table>
   <!--**********************************************帖子列表*****************************************************-->
    
    <div id="v6_pl_content_myfavoriteslist">
            <div>
                <div class="WB_feed">
              
               
         
                    <!--1-->
                    <div class="WB_cardwrap WB_feed_type S_bg2">
                        <div class="WB_feed_detail clearfix">
                           
                            <div class="WB_face W_fl">
                                <div class="face">
                                    <a target="_blank" class="W_face_radius" href="" title="Eexpert">
                                        <img title="srender 晨旭" alt="" width="50" height="50" src="./img/userface/image123.gif" class="W_face_radius"></a>
                                </div>
                            </div>
                            <div class="WB_detail">
                                <div class="WB_info">
                                    <a target="_blank" class="W_f14 W_fb S_txt1" title="Eexpert" href="./dispuser.php">Eexpert</a>
                                    <a  target="_blank" href="">
                                      <span class="W_icon_level icon_level_c3">
                                            <span class="txt_out">
                                            <span class="txt_in">
                                                  <span title="山水等级">
                                                  版主
                                                  </span>
                                            </span>
                                            </span>
                                       </span>
                                    </a>
                                </div>

                                <div class="WB_text W_f14">
                                <a href="./disparticle.php">
                                 年终了，大家评评哪个武大哪个食堂最差？哪个食堂最好？
                                </a>        
                                 </div>
                                <div class="WB_tag clearfix S_txt2">
                                    <span class="W_fr">
                                    发布于 2014.02.10
                                    &nbsp;
                                    <a href="">
                                        [版面名称]
                                    </a>
                                    </span>
                                </div>                            
                            </div>
                        </div>
                        <div class="WB_feed_handle">
                            <div class="WB_handle">
                                <ul class="WB_row_line WB_row_r4 clearfix S_line2">
                                    <li>
                                        <a class="S_txt2" href="javascript:void(0);"><span class="pos"><span class="line S_line1">
                                            回复
                                        </span></span></a>
                                    </li>
                                    <li>
                                        <a class="S_txt2" href="javascript:void(0);">
                                            <span class="pos">
                                                <span class="line S_line1">收藏
                                                </span>
                                            </span>
                                        </a>
                                    </li>
                                 </ul>
                            </div>
                            <div class="WB_feed_repeat S_bg1" style="display: none;"></div>
                        </div>
                    </div>
                    <!--1 end-->

                    <!--2-->
                    <div class="WB_cardwrap WB_feed_type S_bg2">
                        <div class="WB_feed_detail clearfix">
                           
                            <div class="WB_face W_fl">
                                <div class="face">
                                    <a target="_blank" class="W_face_radius" href="" title="Taylor swift">
                                        <img title="srender 晨旭" alt="" width="50" height="50" src="./img/userface/image78.gif" class="W_face_radius"></a>
                                </div>
                            </div>
                            <div class="WB_detail">
                                <div class="WB_info">
                                    <a target="_blank" class="W_f14 W_fb S_txt1" title="srender 晨旭" href="./dispuser.php">Taylor swift</a>
                                    <a  target="_blank" href="">
                                      <span class="W_icon_level icon_level_c3">
                                            <span class="txt_out">
                                            <span class="txt_in">
                                                  <span title="山水等级">版主</span>
                                            </span>
                                            </span>
                                       </span>
                                    </a>
                                </div>

                                <div class="WB_text W_f14">
                                <a href="./disparticle.php">
                                    泰勒·斯威夫特（Taylor Swift），1989年12月13日出生于美国宾夕法尼亚州，美国乡村音乐、流行音乐创作女歌手、演员、慈善家。
                                </a>    
                                </div>

                               <div class="WB_tag clearfix S_txt2">
                                    <span class="W_fr">
                                    发布于 2014.02.10
                                    &nbsp;
                                    <a href="">
                                        [版面名称]
                                    </a>
                                    </span>
                                </div>        
                                <!--
                                <div class="WB_from S_txt2">
                                    <a target="_blank" href="" title="2014-12-06 10:30" class="S_txt2">12月6日 10:30</a>  来自
                                    <a class="S_txt2" target="_blank" href="./board.php" rel="nofollow">版面名称</a>
                                </div>
                            -->
                            </div>
                        </div>
                        <div class="WB_feed_handle">
                            <div class="WB_handle">
                                <ul class="WB_row_line WB_row_r4 clearfix S_line2">
                                  <ul class="WB_row_line WB_row_r4 clearfix S_line2">
                                    <li>
                                        <a class="S_txt2" href="javascript:void(0);"><span class="pos"><span class="line S_line1">
                                            回复
                                        </span></span></a>
                                    </li>
                                    <li>
                                        <a class="S_txt2" href="javascript:void(0);">
                                            <span class="pos">
                                                <span class="line S_line1">收藏
                                                </span>
                                            </span>
                                        </a>
                                    </li>
                                 </ul>
                                </ul>
                            </div>
                            <div class="WB_feed_repeat S_bg1" style="display: none;"></div>
                        </div>
                    </div>
                    <!--2 end-->

                    <!--3-->    
                    <div class="WB_cardwrap WB_feed_type S_bg2">
                        <div class="WB_feed_detail clearfix">
                            <div class="WB_screen W_fr">
                                <div class="screen_box">
                                   
                                </div>
                            </div>
                            <div class="WB_face W_fl">
                                <div class="face">
                                    <a target="_blank" class="W_face_radius" href="" title="srender 晨旭">
                                        <img title="srender 晨旭" alt="" width="50" height="50" src="./img/userface/image23.gif" class="W_face_radius"></a>
                                </div>
                            </div>
                            <div class="WB_detail">
                                <div class="WB_info">
                                    <a target="_blank" class="W_f14 W_fb S_txt1" title="srender 晨旭" href="./dispuser.php">srender 晨旭</a>
                                    <a  target="_blank" href="">
                                      <span class="W_icon_level icon_level_c3">
                                            <span class="txt_out">
                                            <span class="txt_in">
                                                  <span title="山水等级">用户</span>
                                            </span>
                                            </span>
                                       </span>
                                    </a>
                                </div>

                                <div class="WB_text W_f14">
                                <a href="./disparticle.php">
                                《想做web开发，就学JavaScript》为了快速地在web开发工作上增加优势，应该学习什么语言？
                                </a>
                                </div>
                                 <div class="WB_tag clearfix S_txt2">
                                    <span class="W_fr">
                                    发布于 2014.02.10
                                    &nbsp;
                                    <a href="">
                                        [版面名称]
                                    </a>
                                    </span>
                                </div>        

                            </div>
                        </div>
                        <div class="WB_feed_handle">
                            <div class="WB_handle">
                                <ul class="WB_row_line WB_row_r4 clearfix S_line2">
                                   <ul class="WB_row_line WB_row_r4 clearfix S_line2">
                                    <li>
                                        <a class="S_txt2" href="javascript:void(0);"><span class="pos"><span class="line S_line1">
                                            回复
                                        </span></span></a>
                                    </li>
                                    <li>
                                        <a class="S_txt2" href="javascript:void(0);">
                                            <span class="pos">
                                                <span class="line S_line1">收藏
                                                </span>
                                            </span>
                                        </a>
                                    </li>
                                 </ul>
                                </ul>
                            </div>
                            <div class="WB_feed_repeat S_bg1" style="display: none;"></div>
                        </div>
                    </div>
                    <!--3 end-->


                    <!--4-->
                    <div class="WB_cardwrap WB_feed_type S_bg2">
                        <div class="WB_feed_detail clearfix">
                            <div class="WB_screen W_fr">
                                <div class="screen_box">
                                    <a href="javascript:void(0);"><i class="W_ficon ficon_arrow_down S_ficon">c</i></a>
                                    <div class="layer_menu_list" style="display: none; position: absolute; z-index: 999;">
                                      
                                    </div>
                                </div>
                            </div>
                            <div class="WB_face W_fl">
                                <div class="face">
                                    <a target="_blank" class="W_face_radius" href="" title="技术宅的出路">
                                        <img title="srender 晨旭" alt="" width="50" height="50" src="./img/userface/image66.gif" class="W_face_radius"></a>
                                </div>
                            </div>
                            <div class="WB_detail">
                                <div class="WB_info">
                                    <a target="_blank" class="W_f14 W_fb S_txt1" title="技术宅的出路" href="./dispuser.php">技术宅的出路</a>
                                    <a  target="_blank" href="">
                                      <span class="W_icon_level icon_level_c3">
                                            <span class="txt_out">
                                            <span class="txt_in">
                                                  <span title="山水等级">超级用户</span>
                                            </span>
                                            </span>
                                       </span>
                                    </a>
                                </div>

                                <div class="WB_text W_f14">
                                <a href="./disparticle.php">
                                    周杰伦（Jay Chou），1979年1月18日出生于台湾新北市，华语男歌手、词曲创作人、演员、MV及电影导演、编剧及制作人。2000年发行首张个人专辑《Jay》。2002年在中国、新加坡、马来西亚、美国等地举办首场个人世界巡回演唱会。2003年登上美国《时代周刊》亚洲版封面人物[1] 。
                                </a>    
                                </div>
                                <div class="WB_tag clearfix S_txt2">
                                    <span class="W_fr">
                                    发布于 2014.02.10
                                    &nbsp;
                                    <a href="">
                                        [版面名称]
                                    </a>
                                    </span>
                                </div>        

                            </div>
                        </div>
                        <div class="WB_feed_handle">
                            <div class="WB_handle">
                                <ul class="WB_row_line WB_row_r4 clearfix S_line2">
                                    <li>
                                        <a class="S_txt2" href="javascript:void(0);"><span class="pos"><span class="line S_line1">
                                            回复
                                        </span></span></a>
                                    </li>
                                    <li>
                                        <a class="S_txt2" href="javascript:void(0);">
                                            <span class="pos">
                                                <span class="line S_line1">收藏
                                                </span>
                                            </span>
                                        </a>
                                    </li>
                                 </ul>
                            </div>
                            <div class="WB_feed_repeat S_bg1" style="display: none;"></div>
                        </div>
                    </div>                  
                    <!--4 end-->
                </div>
            </div>
        </div>

    </div>

    <!--Pager-->
  <div id="wrapper">
        
            <div id="skyblue" style="margin: auto;">
            </div>
        </div>
    <!--Pager End-->


    <!--***************************************帖子列表*******************************************************-->
    <table class="table">
        <tbody>
            <tr>
                <form method="GET" action="queryresult.php"></form>

                <input type="hidden" name="boardNames" value="Jiangxi">

                <td class="boardsearch">
                     
                     <div class="col-lg-6">
                        <div class="input-group">
                            
                              <input type="text" class="form-control" placeholder="搜索相关内容">
                              <span class="input-group-btn">
                                 <button class="btn btn-default" type="button">Go!</button>
                            </span>
                             </div><!-- /input-group -->
                        </div><!-- /.col-lg-6 -->
                     
                     </div>
                </td>

                <td>
                    <div class="redirectchoice">
                        <select onchange="" class="form-control">
                            <option selected="selected">跳转论坛至...</option>
                            <option value="section.php?sec=0">╋本站系统</option>
                            <option value="board.php?name=Advice">&nbsp;&nbsp;├共建山水</option>
                            <option value="board.php?name=Announce">&nbsp;&nbsp;├站务公告</option>
                            <option value="board.php?name=BBSActivity">&nbsp;&nbsp;├BBS活动</option>
                            <option value="board.php?name=BBSApp">&nbsp;&nbsp;├山水客户端</option>
                            <option value="board.php?name=BBSData">&nbsp;&nbsp;├BBS统计数据</option>
                            <option value="board.php?name=BBSDesign">&nbsp;&nbsp;├BBS美工</option>
                            <option value="board.php?name=BBSHelp">&nbsp;&nbsp;├BBS使用技巧</option>
                            <option value="board.php?name=Blog">&nbsp;&nbsp;├山水Blog</option>
                            <option value="board.php?name=BlogApply">&nbsp;&nbsp;├Blog申请</option>
                            <option value="board.php?name=BoardWork">&nbsp;&nbsp;├版面版务工作</option>
                            <option value="board.php?name=Cherub">&nbsp;&nbsp;├匿名天使的家</option>
                            <option value="board.php?name=Complain">&nbsp;&nbsp;├投诉与仲裁</option>
                            <option value="board.php?name=Death">&nbsp;&nbsp;├珞珈公墓</option>
                            <option value="board.php?name=Election">&nbsp;&nbsp;├本站选举与投票</option>
                            <option value="board.php?name=Honor">&nbsp;&nbsp;├名人堂</option>
                            <option value="board.php?name=Recommend">&nbsp;&nbsp;├推荐文章</option>
                            <option value="board.php?name=Rules">&nbsp;&nbsp;├站规讨论</option>
                            <option value="board.php?name=sysop">&nbsp;&nbsp;├站务讨论</option>
                            <option value="board.php?name=Test">&nbsp;&nbsp;├测试版</option>
                            <option value="section.php?sec=1">╋武汉大学</option>
                            <option value="board.php?name=Freshman">&nbsp;&nbsp;├大一新生</option>
                            <option value="board.php?name=Graduation">&nbsp;&nbsp;├毕业之声</option>
                            <option value="board.php?name=NICNotice">&nbsp;&nbsp;├网络信息中心</option>
                            <option value="board.php?name=Notice">&nbsp;&nbsp;├校园海报栏</option>
                            <option value="board.php?name=PostGraduate">&nbsp;&nbsp;├研究生之家</option>
                            <option value="board.php?name=Teachers">&nbsp;&nbsp;├教工</option>
                            <option value="board.php?name=TMSATWHU">&nbsp;&nbsp;├武大附中</option>
                            <option value="board.php?name=WHDXL">&nbsp;&nbsp;├武汉大学图书馆</option>
                            <option value="board.php?name=WHUAssociations">&nbsp;&nbsp;├协会社团组织</option>
                            <option value="board.php?name=WHUCelebration">&nbsp;&nbsp;├武大校庆</option>
                            <option value="board.php?name=WHUCentury">&nbsp;&nbsp;├皇皇吾大</option>
                            <option value="board.php?name=WHUConnection">&nbsp;&nbsp;├部门直通车</option>
                            <option value="board.php?name=WHUDepartments">&nbsp;&nbsp;├院系风采</option>
                            <option value="board.php?name=WHUExpress">&nbsp;&nbsp;├武大特快</option>
                            <option value="board.php?name=WHUResource">&nbsp;&nbsp;├校园网络资源</option>
                            <option value="section.php?sec=2">╋乡情校谊</option>
                            <option value="board.php?name=Anhui">&nbsp;&nbsp;├淮风皖韵·安徽</option>
                            <option value="board.php?name=BaShu">&nbsp;&nbsp;├巴山蜀水·巴蜀</option>
                            <option value="board.php?name=Beijing">&nbsp;&nbsp;├皇城幽幽·北京</option>
                            <option value="board.php?name=Fujian">&nbsp;&nbsp;├闽海观潮·福建</option>
                            <option value="board.php?name=Gansu">&nbsp;&nbsp;├陇上人家·甘肃</option>
                            <option value="board.php?name=Guangdong">&nbsp;&nbsp;├岭南大地·广东</option>
                            <option value="board.php?name=Guangxi">&nbsp;&nbsp;├八桂大地·广西</option>
                            <option value="board.php?name=Guizhou">&nbsp;&nbsp;├黔山秀水·贵州</option>
                            <option value="board.php?name=Hebei">&nbsp;&nbsp;├慷慨燕赵·河北</option>
                            <option value="board.php?name=Henan">&nbsp;&nbsp;├逐鹿中原·河南</option>
                            <option value="board.php?name=Hubei">&nbsp;&nbsp;├荆风楚韵·湖北</option>
                            <option value="board.php?name=Hunan">&nbsp;&nbsp;├三湘四水·湖南</option>
                            <option value="board.php?name=Jiangsu">&nbsp;&nbsp;├吴韵汉风·江苏</option>
                            <option value="board.php?name=Jiangxi">&nbsp;&nbsp;├江南西道·江西</option>
                            <option value="board.php?name=NorthEast">&nbsp;&nbsp;├白山黑水·东北</option>
                            <option value="board.php?name=Shaanxi">&nbsp;&nbsp;├策马秦川·陕西</option>
                            <option value="board.php?name=Shandong">&nbsp;&nbsp;├齐鲁大地·山东</option>
                            <option value="board.php?name=Shanghai">&nbsp;&nbsp;├风情沪上·上海</option>
                            <option value="board.php?name=Wuhan">&nbsp;&nbsp;├江城风情</option>
                            <option value="board.php?name=Zhejiang">&nbsp;&nbsp;├诗画之江·浙江</option>
                            <option value="section.php?sec=3">╋电脑网络</option>
                            <option value="board.php?name=ACM_ICPC">&nbsp;&nbsp;├国际大学生程序设计竞赛</option>
                            <option value="board.php?name=BBSDev">&nbsp;&nbsp;├BBS安装与维护</option>
                            <option value="board.php?name=CPlusPlus">&nbsp;&nbsp;├C++程序设计</option>
                            <option value="board.php?name=Database">&nbsp;&nbsp;├数据库</option>
                            <option value="board.php?name=Digital">&nbsp;&nbsp;├数码时代</option>
                            <option value="board.php?name=Google">&nbsp;&nbsp;├Google Camp</option>
                            <option value="board.php?name=Hardware">&nbsp;&nbsp;├硬件天地</option>
                            <option value="board.php?name=IBM">&nbsp;&nbsp;├IBM俱乐部</option>
                            <option value="board.php?name=Internet">&nbsp;&nbsp;├万维世界</option>
                            <option value="board.php?name=Java">&nbsp;&nbsp;├爪哇</option>
                            <option value="board.php?name=Linux_Unix">&nbsp;&nbsp;├Linux &amp; Unix</option>
                            <option value="board.php?name=Microsoft">&nbsp;&nbsp;├微软俱乐部</option>
                            <option value="board.php?name=OS">&nbsp;&nbsp;├操作系统</option>
                            <option value="board.php?name=Programm">&nbsp;&nbsp;├程序人生</option>
                            <option value="board.php?name=Security">&nbsp;&nbsp;├系统安全</option>
                            <option value="board.php?name=Software">&nbsp;&nbsp;├软件快递</option>
                            <option value="board.php?name=TeX">&nbsp;&nbsp;├TeX 和 LaTeX</option>
                            <option value="board.php?name=Theory">&nbsp;&nbsp;├计算机理论</option>
                            <option value="section.php?sec=4">╋科学技术</option>
                            <option value="board.php?name=Biology">&nbsp;&nbsp;├生物</option>
                            <option value="board.php?name=Chemistry">&nbsp;&nbsp;├化学</option>
                            <option value="board.php?name=Economics">&nbsp;&nbsp;├经济学</option>
                            <option value="board.php?name=Electronics">&nbsp;&nbsp;├电子电机</option>
                            <option value="board.php?name=Environment">&nbsp;&nbsp;├环境科学</option>
                            <option value="board.php?name=Geography">&nbsp;&nbsp;├地理</option>
                            <option value="board.php?name=History">&nbsp;&nbsp;├历史</option>
                            <option value="board.php?name=Law">&nbsp;&nbsp;├法律</option>
                            <option value="board.php?name=Math">&nbsp;&nbsp;├数学</option>
                            <option value="board.php?name=NumComp">&nbsp;&nbsp;├数值计算</option>
                            <option value="board.php?name=Physics">&nbsp;&nbsp;├物理</option>
                            <option value="board.php?name=Science">&nbsp;&nbsp;├科学</option>
                            <option value="board.php?name=Sex">&nbsp;&nbsp;├人之初</option>
                            <option value="section.php?sec=5">╋文学艺术</option>
                            <option value="board.php?name=ASCIIart">&nbsp;&nbsp;├ASCII艺术</option>
                            <option value="board.php?name=Chorus">&nbsp;&nbsp;├合唱艺术</option>
                            <option value="board.php?name=Classics">&nbsp;&nbsp;├古典及爵士音乐</option>
                            <option value="board.php?name=Comic">&nbsp;&nbsp;├漫画*动画*童话</option>
                            <option value="board.php?name=Emprise">&nbsp;&nbsp;├武侠世界</option>
                            <option value="board.php?name=English">&nbsp;&nbsp;├英语天地</option>
                            <option value="board.php?name=French">&nbsp;&nbsp;├浪漫法兰西</option>
                            <option value="board.php?name=MyStage">&nbsp;&nbsp;├舞台人生</option>
                            <option value="board.php?name=Novels">&nbsp;&nbsp;├小说</option>
                            <option value="board.php?name=Photography">&nbsp;&nbsp;├珞珈摄影</option>
                            <option value="board.php?name=Poetry">&nbsp;&nbsp;├诗词歌赋</option>
                            <option value="board.php?name=Reader">&nbsp;&nbsp;├读书</option>
                            <option value="board.php?name=S.F.">&nbsp;&nbsp;├幻之天空</option>
                            <option value="board.php?name=SanGuo">&nbsp;&nbsp;├青梅煮酒</option>
                            <option value="board.php?name=StoneStory">&nbsp;&nbsp;├红楼梦</option>
                            <option value="board.php?name=Story">&nbsp;&nbsp;├珞珈原创</option>
                            <option value="section.php?sec=6">╋休闲娱乐</option>
                            <option value="board.php?name=Astrology">&nbsp;&nbsp;├星座</option>
                            <option value="board.php?name=Automobile">&nbsp;&nbsp;├车元素</option>
                            <option value="board.php?name=dancing">&nbsp;&nbsp;├舞迷之家</option>
                            <option value="board.php?name=Debate">&nbsp;&nbsp;├唇舌烽火</option>
                            <option value="board.php?name=Family">&nbsp;&nbsp;├寸草春晖</option>
                            <option value="board.php?name=Fashion">&nbsp;&nbsp;├格调生活</option>
                            <option value="board.php?name=Feeling">&nbsp;&nbsp;├心情故事</option>
                            <option value="board.php?name=food">&nbsp;&nbsp;├饮食文化</option>
                            <option value="board.php?name=FreeTalk">&nbsp;&nbsp;├无事闲聊</option>
                            <option value="board.php?name=Game">&nbsp;&nbsp;├计算机游戏</option>
                            <option value="board.php?name=Humor">&nbsp;&nbsp;├幽默</option>
                            <option value="board.php?name=IDstory">&nbsp;&nbsp;├ID故事</option>
                            <option value="board.php?name=KeepFit">&nbsp;&nbsp;├瘦身塑体</option>
                            <option value="board.php?name=KingKiller">&nbsp;&nbsp;├杀人游戏</option>
                            <option value="board.php?name=Love">&nbsp;&nbsp;├情谊两心知</option>
                            <option value="board.php?name=Movie">&nbsp;&nbsp;├电影</option>
                            <option value="board.php?name=Mud">&nbsp;&nbsp;├泥巴乐园</option>
                            <option value="board.php?name=Picture">&nbsp;&nbsp;├贴图版</option>
                            <option value="board.php?name=PieFriends">&nbsp;&nbsp;├缘分的天空</option>
                            <option value="board.php?name=PopMusic">&nbsp;&nbsp;├流行音乐</option>
                            <option value="board.php?name=Riddle">&nbsp;&nbsp;├谜语天地</option>
                            <option value="board.php?name=Rock">&nbsp;&nbsp;├摇滚乐</option>
                            <option value="board.php?name=single">&nbsp;&nbsp;├光辉岁月</option>
                            <option value="board.php?name=Think">&nbsp;&nbsp;├我思故我在</option>
                            <option value="board.php?name=Travel">&nbsp;&nbsp;├海天游踪</option>
                            <option value="board.php?name=TV">&nbsp;&nbsp;├电视</option>
                            <option value="board.php?name=Youth">&nbsp;&nbsp;├青涩时代</option>
                            <option value="section.php?sec=7">╋体育健身</option>
                            <option value="board.php?name=Badminton">&nbsp;&nbsp;├羽毛球</option>
                            <option value="board.php?name=baseball">&nbsp;&nbsp;├棒球</option>
                            <option value="board.php?name=Basketball">&nbsp;&nbsp;├篮球</option>
                            <option value="board.php?name=Bicycle">&nbsp;&nbsp;├一骑绝尘</option>
                            <option value="board.php?name=Bridge">&nbsp;&nbsp;├桥牌</option>
                            <option value="board.php?name=Chess">&nbsp;&nbsp;├珞珈棋缘</option>
                            <option value="board.php?name=Football">&nbsp;&nbsp;├足球</option>
                            <option value="board.php?name=GO">&nbsp;&nbsp;├黑白纵横</option>
                            <option value="board.php?name=Olympic2008">&nbsp;&nbsp;├北京奥运会</option>
                            <option value="board.php?name=Sports">&nbsp;&nbsp;├休闲体育</option>
                            <option value="board.php?name=Tabletennis">&nbsp;&nbsp;├乒乓球</option>
                            <option value="board.php?name=Tennis">&nbsp;&nbsp;├网球</option>
                            <option value="board.php?name=Volleyball">&nbsp;&nbsp;├鲲鹏展翅</option>
                            <option value="board.php?name=Yoga">&nbsp;&nbsp;├瑜伽</option>
                            <option value="section.php?sec=8">╋社会信息</option>
                            <option value="board.php?name=Abroad">&nbsp;&nbsp;├出国·他乡寻梦</option>
                            <option value="board.php?name=ADagent_TG">&nbsp;&nbsp;├代理与团购</option>
                            <option value="board.php?name=EnglishTest">&nbsp;&nbsp;├英语考试</option>
                            <option value="board.php?name=Graduate">&nbsp;&nbsp;├毕业生</option>
                            <option value="board.php?name=House">&nbsp;&nbsp;├房屋租赁</option>
                            <option value="board.php?name=Job">&nbsp;&nbsp;├工作</option>
                            <option value="board.php?name=JobInfo">&nbsp;&nbsp;├工作信息</option>
                            <option value="board.php?name=kaoyan">&nbsp;&nbsp;├考研信息港</option>
                            <option value="board.php?name=Medicine">&nbsp;&nbsp;├医疗保健</option>
                            <option value="board.php?name=Military">&nbsp;&nbsp;├军事天地</option>
                            <option value="board.php?name=MyWallet">&nbsp;&nbsp;├投资理财</option>
                            <option value="board.php?name=News">&nbsp;&nbsp;├新闻</option>
                            <option value="board.php?name=PartTimeJob">&nbsp;&nbsp;├兼职信息</option>
                            <option value="board.php?name=Search">&nbsp;&nbsp;├失物招领</option>
                            <option value="board.php?name=secondhand">&nbsp;&nbsp;├二手货交易市场</option>
                            <option value="board.php?name=TrafficInfo">&nbsp;&nbsp;├交通信息</option>
                            <option value="board.php?name=WHU">&nbsp;&nbsp;├珞珈论坛</option>
                            <option value="board.php?name=Wish">&nbsp;&nbsp;├生日·祝福</option>
                        </select>
                    </div>
                </td>
            </tr>
        </tbody>
    </table>

    <!-- search end-->
</div>


  <script type="text/javascript">
        $(document).ready(function () {

          $('#skyblue').smartpaginator({ totalrecords: 32, recordsperpage: 4, length: 4, next: '下一页', prev: '前一页', first: '首页', last: '尾页', theme: 'skyblue', controlsalways: true, onchange: function (newPage) {
                $('#r').html('Page # ' + newPage);
            }
            });

        });
    </script>
<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 9999, null, array(), 0);?>

<?php }} ?>
