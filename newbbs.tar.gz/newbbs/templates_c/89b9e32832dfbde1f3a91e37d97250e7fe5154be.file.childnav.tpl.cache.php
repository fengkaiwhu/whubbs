<?php /* Smarty version Smarty-3.1.18, created on 2014-12-24 13:57:15
         compiled from ".\templates\childnav.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2236054956999c78317-37409694%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '89b9e32832dfbde1f3a91e37d97250e7fe5154be' => 
    array (
      0 => '.\\templates\\childnav.tpl',
      1 => 1419423344,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2236054956999c78317-37409694',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.18',
  'unifunc' => 'content_54956999c7c197_31118843',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_54956999c7c197_31118843')) {function content_54956999c7c197_31118843($_smarty_tpl) {?><nav class="navbar navbar-default userdefine" role="navigation">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
     
      <a class="navbar-brand" href="#"> 
      	珞珈山水
      </a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li>
        	<a href="./usermanagemenu.php">控制面板首页</a>
        </li>
        <li>
        	<a href="./modifyuserdata.php">基本资料修改</a>
        </li>
       	<li>
        	<a href="./changepasswd.php">昵称密码修改</a>
        </li>

        <li>
        	<a href="./userparam.php">用户自定义参数</a>
        </li>
        <li>
        	<a href="./usermailbox.php">用户信件服务</a>
        </li>
       	<li>
        	<a href="./friendlist.php">编辑好友列表</a>
        </li>
     	
     	<li>
        	<a href="./modifyfavboards.php">收藏版面管理</a>
        </li>
      </ul>
     
	    </div><!-- /.navbar-collapse -->
	  </div><!-- /.container-fluid -->
	</nav><?php }} ?>
